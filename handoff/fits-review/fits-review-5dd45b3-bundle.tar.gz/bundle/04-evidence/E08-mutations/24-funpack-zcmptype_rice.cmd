/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-zcmptype_rice.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-zcmptype_rice.fits
