/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-gzip_method_byte.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-gzip_method_byte.fits
