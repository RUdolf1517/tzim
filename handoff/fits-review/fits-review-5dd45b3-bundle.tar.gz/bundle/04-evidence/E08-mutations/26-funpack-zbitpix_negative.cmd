/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-zbitpix_negative.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-zbitpix_negative.fits
