/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-znaxis2_less.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-znaxis2_less.fits
