/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-tile_byte_200.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-tile_byte_200.fits
