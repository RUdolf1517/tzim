/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-tile_byte_60.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-tile_byte_60.fits
