/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-extname_renamed.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-extname_renamed.fits
