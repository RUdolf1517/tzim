/tmp/cfitsio-src/fitsverify -l /home/user/fits-review/bundle/01-fixtures/derived/mutant-tile_crc_flipped.fits
