/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-zsimple_false.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-zsimple_false.fits
