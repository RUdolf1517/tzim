/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-znaxis1_halved.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-znaxis1_halved.fits
