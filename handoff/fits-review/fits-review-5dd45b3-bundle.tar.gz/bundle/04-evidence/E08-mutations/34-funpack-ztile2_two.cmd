/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-ztile2_two.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-ztile2_two.fits
