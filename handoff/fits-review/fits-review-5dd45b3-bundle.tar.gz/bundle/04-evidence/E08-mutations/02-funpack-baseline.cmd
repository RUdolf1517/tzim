/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/mutant-baseline.unpacked.fits /home/user/fits-review/bundle/01-fixtures/derived/mutant-baseline.fits
