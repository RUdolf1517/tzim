/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/E14-fpack-g-q0.decoded.fits /home/user/fits-review/bundle/01-fixtures/derived/float32_specials.fpack.fits
