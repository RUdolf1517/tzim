/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/E14-fpack-g2-q0.decoded.fits /home/user/fits-review/bundle/01-fixtures/derived/float32_specials.e14-fpack-g2.fits
