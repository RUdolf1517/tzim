/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/E14-tzim.decoded.fits /home/user/fits-review/bundle/01-fixtures/derived/float32_specials.tzim-candidate.fits
