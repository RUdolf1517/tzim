/tmp/venv/bin/python -c 'import sys
from astropy.io import fits
import numpy as np
src, dst = sys.argv[1], sys.argv[2]
with fits.open(src) as hdul:
    hdu = hdul[0]
    data = np.asarray(hdu.data)
    out = fits.CompImageHDU(data=data, compression_type='"'"'GZIP_2'"'"',
                            quantize_level=0)
    out.writeto(dst, overwrite=True)
    print('"'"'wrote'"'"', dst)
' /home/user/fits-review/bundle/01-fixtures/float32_specials.fits /home/user/fits-review/bundle/01-fixtures/derived/float32_specials.astropy.fits
