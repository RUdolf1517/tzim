/tmp/cfitsio-src/fpack -g2 -q 0 -F -O /home/user/fits-review/bundle/01-fixtures/derived/float8.fpack-g2.fits /home/user/fits-review/bundle/01-fixtures/derived/float8.fits
