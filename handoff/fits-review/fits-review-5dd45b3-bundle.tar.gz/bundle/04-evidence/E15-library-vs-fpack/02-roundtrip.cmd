/tmp/cfitsio-roundtrip
