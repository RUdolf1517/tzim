/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/float8.fpack-g2.decoded.fits /home/user/fits-review/bundle/01-fixtures/derived/float8.fpack-g2.fits
