/tmp/cfitsio-src/fitsverify -l /tmp/cfitsio-roundtrip.fits
