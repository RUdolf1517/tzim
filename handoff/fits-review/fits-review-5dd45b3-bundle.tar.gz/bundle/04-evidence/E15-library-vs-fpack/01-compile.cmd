gcc -O0 -I/tmp/cfitsio-src -o /tmp/cfitsio-roundtrip /home/user/fits-review/bundle/05-tools/cfitsio-roundtrip.c -L/tmp/cfitsio-src/.libs -lcfitsio -Wl,-rpath,/tmp/cfitsio-src/.libs
