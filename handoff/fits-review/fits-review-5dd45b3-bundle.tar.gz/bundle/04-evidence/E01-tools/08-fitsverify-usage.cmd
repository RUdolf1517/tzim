/tmp/cfitsio-src/fitsverify -h
