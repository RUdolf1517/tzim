/tmp/cfitsio-src/funpack -V
