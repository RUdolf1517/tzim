git -C /tmp/cfitsio-src rev-parse HEAD
