git -C /tmp/cfitsio-src remote -v
