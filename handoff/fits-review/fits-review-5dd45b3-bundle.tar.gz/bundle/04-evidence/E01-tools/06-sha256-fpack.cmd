sha256sum /tmp/cfitsio-src/fpack
