git -C /tmp/cfitsio-src describe --always --tags
