sha256sum /tmp/cfitsio-src/funpack
