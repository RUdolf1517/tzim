/tmp/cfitsio-src/funpack -H
