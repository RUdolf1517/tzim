git -C /tmp/cfitsio-src log -1 --format=%H%n%ci%n%s
