sha256sum /tmp/cfitsio-src/fitsverify
