/tmp/cfitsio-src/fitsverify -l /home/user/fits-review/bundle/01-fixtures/bscale_two_five.fits
