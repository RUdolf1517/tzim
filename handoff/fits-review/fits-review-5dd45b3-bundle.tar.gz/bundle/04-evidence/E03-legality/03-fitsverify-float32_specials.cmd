/tmp/cfitsio-src/fitsverify -l /home/user/fits-review/bundle/01-fixtures/float32_specials.fits
