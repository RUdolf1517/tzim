/tmp/cfitsio-src/fitsverify -l /home/user/fits-review/bundle/01-fixtures/int16_primary.fits
