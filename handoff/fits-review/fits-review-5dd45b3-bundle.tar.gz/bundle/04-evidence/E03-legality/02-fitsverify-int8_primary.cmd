/tmp/cfitsio-src/fitsverify -l /home/user/fits-review/bundle/01-fixtures/int8_primary.fits
