/tmp/cfitsio-src/fitsverify -l /home/user/fits-review/bundle/01-fixtures/simple_f_data.fits
