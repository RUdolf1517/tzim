/tmp/cfitsio-src/fitsverify -l /home/user/fits-review/bundle/01-fixtures/extend_f_primary.fits
