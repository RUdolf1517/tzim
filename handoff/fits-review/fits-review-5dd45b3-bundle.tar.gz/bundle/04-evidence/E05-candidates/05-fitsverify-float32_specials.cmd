/tmp/cfitsio-src/fitsverify -l /home/user/fits-review/bundle/01-fixtures/derived/float32_specials.tzim-candidate.fits
