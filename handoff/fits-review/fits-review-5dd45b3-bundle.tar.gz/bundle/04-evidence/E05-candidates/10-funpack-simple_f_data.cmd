/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/simple_f_data.reconstructed.fits /home/user/fits-review/bundle/01-fixtures/derived/simple_f_data.tzim-candidate.fits
