/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/int8_primary.reconstructed.fits /home/user/fits-review/bundle/01-fixtures/derived/int8_primary.tzim-candidate.fits
