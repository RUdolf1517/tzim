/tmp/cfitsio-src/fitsverify -l /home/user/fits-review/bundle/01-fixtures/derived/int16_primary.tzim-candidate.fits
