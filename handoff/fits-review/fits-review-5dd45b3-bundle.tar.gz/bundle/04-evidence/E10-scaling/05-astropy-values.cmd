/tmp/venv/bin/python -c 'import sys
import numpy as np
from astropy.io import fits
for path in sys.argv[1:]:
    with fits.open(path) as hdul:
        hdu = next(h for h in hdul if h.data is not None)
        data = np.asarray(hdu.data)
        print(path)
        print('"'"'  dtype'"'"', data.dtype, '"'"'shape'"'"', data.shape)
        print('"'"'  first 6:'"'"', data.ravel()[:6].tolist())
        print('"'"'  BSCALE'"'"', hdu.header.get('"'"'BSCALE'"'"'), '"'"'BZERO'"'"', hdu.header.get('"'"'BZERO'"'"'))
' /home/user/fits-review/bundle/01-fixtures/bzero_float.fits /home/user/fits-review/bundle/01-fixtures/derived/bzero_float.reconstructed.fits /home/user/fits-review/bundle/01-fixtures/bscale_two_five.fits /home/user/fits-review/bundle/01-fixtures/derived/bscale_two_five.reconstructed.fits
