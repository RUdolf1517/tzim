/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/bzero_float.reconstructed.fits /home/user/fits-review/bundle/01-fixtures/derived/bzero_float.tzim-candidate.fits
