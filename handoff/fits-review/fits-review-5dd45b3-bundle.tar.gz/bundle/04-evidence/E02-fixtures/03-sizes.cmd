bash -lc 'ls -l /home/user/fits-review/bundle/01-fixtures/*.fits'
