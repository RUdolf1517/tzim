/tmp/venv/bin/python /home/user/fits-review/bundle/01-fixtures/make_fixtures.py
