gcc --version
