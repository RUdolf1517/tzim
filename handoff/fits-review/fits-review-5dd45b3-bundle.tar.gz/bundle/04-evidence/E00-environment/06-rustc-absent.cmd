bash -lc 'command -v rustc || echo '"'"'rustc: not found'"'"''
