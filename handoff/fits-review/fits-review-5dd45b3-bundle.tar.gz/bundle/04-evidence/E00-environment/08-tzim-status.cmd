git -C /home/user/tzim status --porcelain=v1
