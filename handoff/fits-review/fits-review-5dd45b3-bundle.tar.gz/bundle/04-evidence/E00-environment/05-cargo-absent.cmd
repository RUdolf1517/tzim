bash -lc 'command -v cargo || echo '"'"'cargo: not found'"'"''
