bash -lc 'grep -n '"'"'^version'"'"' /home/user/tzim/Cargo.toml'
