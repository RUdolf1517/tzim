/tmp/venv/bin/python -c 'import numpy, astropy; print('"'"'numpy'"'"', numpy.__version__); print('"'"'astropy'"'"', astropy.__version__)'
