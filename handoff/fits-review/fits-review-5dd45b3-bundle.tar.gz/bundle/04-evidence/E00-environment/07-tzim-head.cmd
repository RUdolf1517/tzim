git -C /home/user/tzim rev-parse HEAD
