/tmp/cfitsio-src/fpack -g -q 0 -O /home/user/fits-review/bundle/01-fixtures/derived/float32_specials.fpack.fits /home/user/fits-review/bundle/01-fixtures/float32_specials.fits
