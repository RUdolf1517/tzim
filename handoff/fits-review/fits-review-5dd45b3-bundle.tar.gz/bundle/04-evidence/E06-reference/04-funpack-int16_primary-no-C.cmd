/tmp/cfitsio-src/funpack -O /home/user/fits-review/bundle/01-fixtures/derived/int16_primary.fpack.funpack.no-C.fits /home/user/fits-review/bundle/01-fixtures/derived/int16_primary.fpack.fits
