/tmp/cfitsio-src/fpack -g -O /home/user/fits-review/bundle/01-fixtures/derived/int16_primary.fpack.fits /home/user/fits-review/bundle/01-fixtures/int16_primary.fits
