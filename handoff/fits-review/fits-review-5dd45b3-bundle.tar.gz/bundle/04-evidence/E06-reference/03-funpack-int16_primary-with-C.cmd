/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/int16_primary.fpack.funpack.with-C.fits /home/user/fits-review/bundle/01-fixtures/derived/int16_primary.fpack.fits
