/tmp/cfitsio-src/funpack -O /home/user/fits-review/bundle/01-fixtures/derived/float32_specials.fpack.funpack.no-C.fits /home/user/fits-review/bundle/01-fixtures/derived/float32_specials.fpack.fits
