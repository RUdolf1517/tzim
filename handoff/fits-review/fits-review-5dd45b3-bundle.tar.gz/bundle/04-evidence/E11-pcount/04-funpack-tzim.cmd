/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/pcount_primary.reconstructed.fits /home/user/fits-review/bundle/01-fixtures/derived/pcount_primary.tzim-candidate.fits
