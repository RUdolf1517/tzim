/tmp/cfitsio-src/funpack -C -O /home/user/fits-review/bundle/01-fixtures/derived/pcount_primary.fpack.funpack.fits /home/user/fits-review/bundle/01-fixtures/derived/pcount_primary.fpack.fits
