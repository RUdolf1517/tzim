/tmp/cfitsio-src/fpack -O /home/user/fits-review/bundle/01-fixtures/derived/pcount_primary.fpack.fits /home/user/fits-review/bundle/01-fixtures/pcount_primary.fits
