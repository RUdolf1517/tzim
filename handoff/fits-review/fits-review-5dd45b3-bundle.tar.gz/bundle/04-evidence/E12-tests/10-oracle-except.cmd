cd /home/user/tzim && grep -n 'except Exception' .github/scripts/fits-oracle.py
