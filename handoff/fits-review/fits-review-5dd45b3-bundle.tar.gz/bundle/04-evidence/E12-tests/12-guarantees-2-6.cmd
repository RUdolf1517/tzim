cd /home/user/tzim && sed -n 82,100p docs/guarantees.md
