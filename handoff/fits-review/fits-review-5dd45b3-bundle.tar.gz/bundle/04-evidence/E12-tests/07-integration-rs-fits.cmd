cd /home/user/tzim && grep -n 'fn fits' tests/integration.rs
