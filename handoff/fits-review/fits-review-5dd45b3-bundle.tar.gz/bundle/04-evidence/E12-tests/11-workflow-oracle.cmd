cd /home/user/tzim && grep -n fits-oracle .github/workflows/ci.yml
