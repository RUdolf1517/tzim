cd /home/user/tzim && grep -n equal_nan .github/scripts/fits-oracle.py
