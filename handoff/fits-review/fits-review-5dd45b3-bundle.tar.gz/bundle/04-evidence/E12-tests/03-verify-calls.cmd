cd /home/user/tzim && grep -n 'verify(' src/formats/fits.rs
