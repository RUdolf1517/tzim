cd /home/user/tzim && grep -n -i fits tests/verification.rs
