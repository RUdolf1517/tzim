cd /home/user/tzim && sed -n 860,940p src/formats/fits.rs
