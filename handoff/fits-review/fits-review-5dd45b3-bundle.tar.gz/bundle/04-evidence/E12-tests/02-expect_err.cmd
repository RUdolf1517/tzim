cd /home/user/tzim && grep -n expect_err src/formats/fits.rs
