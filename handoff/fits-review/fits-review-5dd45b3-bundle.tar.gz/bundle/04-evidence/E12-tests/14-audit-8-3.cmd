cd /home/user/tzim && sed -n 300,315p docs/fits-audit.md
