cd /home/user/tzim && sed -n 452,470p src/formats/fits.rs
