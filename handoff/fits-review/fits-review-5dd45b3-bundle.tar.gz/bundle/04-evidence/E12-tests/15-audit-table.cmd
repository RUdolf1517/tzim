cd /home/user/tzim && sed -n 148,160p docs/fits-audit.md
