cd /home/user/tzim && grep -n 'tobytes\|array_equal' .github/scripts/fits-oracle.py
