cd /home/user/tzim && grep -n -E '^    fn [a-z_0-9]+\(\)' src/formats/fits.rs
