cd /home/user/tzim && sed -n 1005,1145p docs/guarantees.md
