#!/usr/bin/env python3
"""A line-by-line transcription of the *reader/decider* in src/formats/fits.rs.

Used to answer one question per fixture: what would tzim do with this file —
`Decline`/`Keep` (skipped, exit 0) or `Error::Parse` (failed, exit 1)? The
transcription covers:

  Card::keyword/field/int/truth/text   fits.rs:100-155
  parse_header()                        fits.rs:294-322
  declared_data_len()                   fits.rs:304-360
  classify()                            fits.rs:362-387
  scan()                                fits.rs:389-430
  decide_image() / decide()             fits.rs:474-517, 523-542

As with model.py: this is not the shipped binary. It is the Rust read path
transcribed, so that the *fixture* can be fed to the real CFITSIO and the
*decision* can be shown without a Rust toolchain.
"""

RECORD = 2880
CARD = 80
MAX_HEADER_RECORDS = 4096
MAX_NAXIS = 999
BITPIX_VALUES = (8, 16, 32, 64, -32, -64)


class ParseError(Exception):
    """`Error::parse` — pipeline.rs maps it to Status::Failed, exit 1."""


class Refused(Exception):
    """`Error::refused` — pipeline.rs maps it to Status::Skipped, exit 0."""


class Limit(Exception):
    """`Error::limit` — pipeline.rs maps it to Status::Skipped, exit 0."""


class Card:
    def __init__(self, raw: bytes):
        assert len(raw) == CARD
        self.raw = raw

    def keyword(self) -> str:
        end = 8
        while end > 0 and self.raw[end - 1] == 0x20:
            end -= 1
        try:
            return self.raw[:end].decode("utf-8")
        except UnicodeDecodeError:
            return ""

    def field(self) -> str:
        try:
            return self.raw[10:30].decode("utf-8").rstrip()
        except UnicodeDecodeError:
            return ""

    def int(self):
        text = self.field().strip()
        if not text:
            return None
        try:
            # str::parse::<i64> in Rust: no floats, no leading '+', no spaces.
            if text[0] == "+":
                raise ValueError
            return int(text, 10)
        except ValueError:
            return None

    def truth(self):
        value = self.field().strip()
        return True if value == "T" else False if value == "F" else None

    def text(self):
        text = self.field().lstrip()
        if not text.startswith("'"):
            return None
        rest = text[1:]
        end = rest.rfind("'")
        if end < 0:
            return None
        return rest[:end]


class Header:
    def __init__(self, cards, start, byte_count):
        self.cards = cards
        self.start = start
        self.bytes = byte_count

    def get(self, keyword):
        for card in self.cards:
            if card.keyword() == keyword:
                return card
        return None

    def has(self, keyword):
        return self.get(keyword) is not None

    def count(self, keyword):
        return sum(1 for card in self.cards if card.keyword() == keyword)

    def int(self, keyword):
        card = self.get(keyword)
        return card.int() if card else None

    def truth(self, keyword):
        card = self.get(keyword)
        return card.truth() if card else None

    def text(self, keyword):
        card = self.get(keyword)
        return card.text() if card else None


def parse_header(data: bytes, start: int):
    cards = []
    offset = start
    records = 0
    while True:
        if offset + RECORD > len(data):
            raise ParseError("fits: a header record runs past the end of the file")
        if records >= MAX_HEADER_RECORDS:
            raise Limit("fits: header is longer than 4096 records")
        record = data[offset:offset + RECORD]
        records += 1
        for within in range(0, RECORD, CARD):
            raw = record[within:within + CARD]
            card = Card(raw)
            if card.keyword() == "END":
                rest = record[within + CARD:]
                if any(byte != 0x20 for byte in rest):
                    raise ParseError("fits: bytes after the END card")
                return Header(cards, start, offset + RECORD - start)
            cards.append(card)
        offset += RECORD


def declared_data_len(header: Header):
    bitpix = header.int("BITPIX")
    if bitpix is None:
        raise ParseError("fits: header has no BITPIX card")
    if bitpix not in BITPIX_VALUES:
        raise Refused("fits: BITPIX %d is not one of 8, 16, 32, 64, -32 or -64" % bitpix)
    naxis = header.int("NAXIS")
    if naxis is None:
        raise ParseError("fits: header has no NAXIS card")
    if naxis < 0:
        raise ParseError("fits: NAXIS is negative")
    if naxis > MAX_NAXIS:
        raise Limit("fits: NAXIS = %d is beyond the standard's limit of %d" % (naxis, MAX_NAXIS))
    axes = []
    product = 1
    for axis in range(1, naxis + 1):
        name = "NAXIS%d" % axis
        length = header.int(name)
        if length is None:
            raise ParseError("fits: header has no %s card" % name)
        if length < 0:
            raise ParseError("fits: %s is negative" % name)
        axes.append(length)
        product *= length
    if naxis == 0:
        product = 0
        axes.clear()
    pcount = header.int("PCOUNT")
    pcount = 0 if pcount is None else pcount
    gcount = header.int("GCOUNT")
    gcount = 1 if gcount is None else gcount
    if pcount < 0 or gcount <= 0:
        raise ParseError("fits: PCOUNT or GCOUNT is out of range")
    per_sample = abs(bitpix) // 8
    total = per_sample * (product + pcount) * gcount
    return bitpix, axes, total


def classify(header: Header, index: int) -> str:
    if header.has("SIMPLE"):
        if index != 0:
            raise ParseError("fits: a second primary HDU")
        return "Primary"
    extension = header.text("XTENSION")
    if extension is None:
        raise ParseError("fits: an HDU with neither SIMPLE nor XTENSION")
    name = extension.strip()
    if name == "IMAGE":
        return "ImageExt"
    if name == "BINTABLE":
        return "BinTable"
    if name == "TABLE":
        return "AsciiTable"
    return "Other"


class Hdu:
    def __init__(self, header, kind, bitpix, axes, data_start, data_len, end):
        self.header = header
        self.kind = kind
        self.bitpix = bitpix
        self.axes = axes
        self.data_start = data_start
        self.data_len = data_len
        self.end = end


def scan(data: bytes):
    if len(data) < RECORD:
        raise ParseError("fits: shorter than one 2880-byte record")
    hdus = []
    offset = 0
    while offset < len(data):
        header = parse_header(data, offset)
        index = len(hdus)
        kind = classify(header, index)
        bitpix, axes, data_len = declared_data_len(header)
        data_start = header.start + header.bytes
        available = len(data) - data_start
        if data_len > available:
            raise ParseError(
                "fits: HDU %d declares %d bytes of data and the file holds %d"
                % (index, data_len, available))
        padded = (data_len + RECORD - 1) // RECORD * RECORD
        if padded > available:
            raise ParseError("fits: HDU %d is not padded to a whole 2880-byte record" % index)
        end = data_start + padded
        hdus.append(Hdu(header, kind, bitpix, axes, data_start, data_len, end))
        offset = end
    if offset != len(data):
        raise ParseError("fits: trailing bytes after the last HDU")
    return hdus


def decide_image(hdu: Hdu) -> str:
    header = hdu.header
    if header.has("ZIMAGE") or header.has("ZCMPTYPE"):
        return "Decline: fits: an image HDU carrying Z* cards"
    if header.truth("GROUPS") is True:
        return "Decline: fits: random groups (GROUPS = T)"
    if (header.int("PCOUNT") or 0) != 0 or (header.int("GCOUNT") or 1) != 1:
        return "Decline: fits: an image HDU with PCOUNT or GCOUNT set"
    scale = header.int("BSCALE")
    scale = 1 if scale is None else scale
    zero = header.int("BZERO")
    zero = 0 if zero is None else zero
    if scale != 1 or zero != 0:
        return "Decline: fits: the image is scaled (BSCALE = %d, BZERO = %d)" % (scale, zero)
    if header.has("CHECKSUM") or header.has("DATASUM"):
        return "Decline: fits: the HDU carries CHECKSUM/DATASUM"
    if header.count("EXTNAME") > 1:
        return "Decline: fits: more than one EXTNAME card"
    if hdu.bitpix not in BITPIX_VALUES:
        return "Decline: fits: BITPIX %d" % hdu.bitpix
    if 0 in hdu.axes:
        return "Decline: fits: an axis of length zero"
    if not hdu.axes or hdu.data_len == 0:
        return "Keep"
    return "Tile"


def decide(hdu: Hdu) -> str:
    if hdu.kind in ("Primary", "ImageExt"):
        return decide_image(hdu)
    if hdu.kind == "BinTable" and hdu.header.truth("ZIMAGE") is True:
        codec = (hdu.header.text("ZCMPTYPE") or "").strip()
        if codec in ("GZIP_1", "GZIP_2"):
            return "Keep"
        return "Decline: fits: the image tiles are %s" % codec
    return "Keep"


def outcome(path: str):
    """Exactly what pipeline.rs would make of the file: status + note."""
    data = open(path, "rb").read()
    try:
        hdus = scan(data)
    except ParseError as error:
        return {"status": "failed", "exit": 1, "reason": str(error)}
    except (Refused, Limit) as error:
        return {"status": "skipped", "exit": 0, "reason": str(error)}
    decisions = [decide(hdu) for hdu in hdus]
    if all(d.startswith(("Decline", "Keep")) for d in decisions):
        note = next((d.split(": ", 1)[1] for d in decisions if d.startswith("Decline")), "")
        return {"status": "skipped", "exit": 0, "reason": note or "nothing to do"}
    return {"status": "would-rewrite", "exit": 0, "reason": "; ".join(decisions)}
