#!/usr/bin/env python3
"""E05: the candidate the transcribed writer produces, judged by real CFITSIO.

For each image fixture: build the candidate exactly as `write_tiled()` +
`empty_primary()` would (bypassing only the *size* gate, so that a format can be
judged even where tzim would decline for lack of gain), then

  1. `fitsverify -l`          — is it a legal FITS file?
  2. `funpack -C`             — does the reference decoder reconstruct it?
  3. byte comparison          — is the reconstructed array identical to the input?

Every command's stdout/stderr/exit is stored under 04-evidence/E05-candidates/.
"""
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
FIXTURES = os.path.join(BUNDLE, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
EVIDENCE = os.path.join(BUNDLE, "04-evidence")
sys.path.insert(0, HERE)
import model  # noqa: E402
from harness import Experiment, array_bytes, card_diff, cards_of, header_of  # noqa: E402

os.makedirs(DERIVED, exist_ok=True)

CASES = [
    ("int16_primary", 16, [256, 256], ">i2"),
    ("int8_primary", 8, [100, 100], ">u1"),
    ("float32_specials", -32, [48, 64], ">f4"),
    ("extend_f_primary", 16, [256, 256], ">i2"),
    ("simple_f_data", 8, [256, 256], ">u1"),
]


from fixture_hdu import forced_candidate, hdu_from_file  # noqa: E402


experiment = Experiment(
    "E05-candidates",
    "Is the transcribed writer's output legal, decodable, and does it round trip "
    "byte for byte?")
summary = []

for name, bitpix, axes, dtype in CASES:
    original = os.path.join(FIXTURES, name + ".fits")
    hdu = hdu_from_file(original)
    optimized = model.optimize([hdu])
    if optimized is None:
        candidate = forced_candidate(hdu)
        size_gate = "no-gain: candidate forced, so the format can still be judged"
    else:
        candidate = optimized
        size_gate = "passed: this is the candidate tzim would write"
    candidate_path = os.path.join(DERIVED, name + ".tzim-candidate.fits")
    with open(candidate_path, "wb") as handle:
        handle.write(candidate)

    record = {
        "fixture": name,
        "original": original,
        "original_bytes": os.path.getsize(original),
        "candidate": candidate_path,
        "candidate_bytes": len(candidate),
        "optimize_would_return_nogain": optimized is None,
        "size_gate": size_gate,
    }

    record["fitsverify_exit"] = experiment.fitsverify(
        "fitsverify-" + name, candidate_path)["exit"]

    reconstructed = os.path.join(DERIVED, name + ".reconstructed.fits")
    if os.path.exists(reconstructed):
        os.remove(reconstructed)
    unpack = experiment.funpack("funpack-" + name, candidate_path, reconstructed)
    record["funpack_exit"] = unpack["exit"]
    record["reconstructed_exists"] = os.path.exists(reconstructed)

    if os.path.exists(reconstructed):
        before = open(original, "rb").read()
        after = open(reconstructed, "rb").read()
        record["array_identical"] = array_bytes(original) == array_bytes(reconstructed)
        record["array_sha256_original"] = hashlib.sha256(array_bytes(original)).hexdigest()
        record["array_sha256_reconstructed"] = hashlib.sha256(array_bytes(reconstructed)).hexdigest()
        record["header_byte_identical"] = header_of(original) == header_of(reconstructed)
        record["header_diff"] = card_diff(header_of(original), header_of(reconstructed))
    summary.append(record)

experiment.note("summary", rows=summary)
experiment.save()

with open(os.path.join(EVIDENCE, "E05-summary.json"), "w") as handle:
    json.dump(summary, handle, indent=2)
    handle.write("\n")

print()
print("%-20s %8s %8s %-9s %-9s %-9s" % ("fixture", "orig", "cand", "verify", "funpack",
                                        "array=="))
for row in summary:
    print("%-20s %8d %8d %-9s %-9s %-9s" % (
        row["fixture"], row["original_bytes"], row["candidate_bytes"],
        row["fitsverify_exit"], row["funpack_exit"], row.get("array_identical")))
