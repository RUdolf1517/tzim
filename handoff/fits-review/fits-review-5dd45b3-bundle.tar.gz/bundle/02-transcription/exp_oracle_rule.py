#!/usr/bin/env python3
"""E14: the gate's own `check_rewritten` on three candidates, plus who loses float bits.

Part 1 uses `check_rewritten` **imported from `.github/scripts/fits-oracle.py`**
at the reviewed SHA; no rule is re-implemented here.

Part 2 answers the question part 1 raises: the reference `fpack` in this sandbox
does not round-trip the float fixture bit for bit. This measures which writer
loses which bits, so that the loss is not mistaken for a defect of the file
format or of tzim.
"""
import importlib.util
import os
import sys

import numpy as np
from astropy.io import fits

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
FIXTURES = os.path.join(BUNDLE, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
REPO = "/home/user/tzim"
sys.path.insert(0, HERE)
import model  # noqa: E402
from fixture_hdu import forced_candidate, hdu_from_file  # noqa: E402
from harness import Experiment  # noqa: E402

spec = importlib.util.spec_from_file_location(
    "fits_oracle", os.path.join(REPO, ".github/scripts/fits-oracle.py"))
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)

experiment = Experiment("E14-oracle-rule",
                        "The oracle's own check_rewritten on a good, a legal-but-"
                        "different and a tampered candidate; and who loses float bits")

original = os.path.join(FIXTURES, "float32_specials.fits")
original_bytes = open(original, "rb").read()
expected = np.asarray(fits.getdata(original, 0))
print("original: shape %s dtype %s, %d bytes"
      % (expected.shape, expected.dtype, len(original_bytes)))


def case_for():
    return {"expected": {0: expected}, "arrays": [(0, 1)],
            "metadata": [], "tables": [1], "verbatim": []}


# ---- 1. the transcribed writer's candidate ---------------------------------
tzim_candidate = os.path.join(DERIVED, "float32_specials.tzim-candidate.fits")
problems = oracle.check_rewritten(tzim_candidate, original_bytes, case_for())
print("\n[1] tzim-candidate (GZIP_2): %d problem(s)" % len(problems))
for problem in problems:
    print("    -", problem)
experiment.note("tzim-candidate", problems=problems)

# ---- 2. a legal GZIP_1 float file written by fpack -------------------------
gzip1 = os.path.join(DERIVED, "float32_specials.fpack.fits")
raw = open(gzip1, "rb").read()
codec = oracle.walk(raw)[1].text("ZCMPTYPE")
bitpix = oracle.walk(raw)[1].int("ZBITPIX")
print("\n[2] fpack candidate: ZCMPTYPE=%r ZBITPIX=%r (fpack -g -q 0)" % (codec, bitpix))
problems = oracle.check_rewritten(gzip1, original_bytes, case_for())
print("    gate: %d problem(s)" % len(problems))
for problem in problems:
    print("    -", problem)
experiment.note("fpack-gzip1", codec=codec, zbitpix=bitpix, problems=problems)

# ---- 3. a candidate that differs from the original in one NaN payload ------
# Built by the *transcription*, because it is the only writer here known to be
# bit-exact on this fixture; astropy's writer is measured in part 4.
hdu = hdu_from_file(original)
tampered = bytearray(hdu.data)
bits = np.frombuffer(bytes(tampered), dtype=">u4")
target = [i for i, value in enumerate(bits) if value == 0x7FC00002]
print("\n[3] NaN payload 0x7FC00002 at pixel(s) %s; writing 0x7FC00001" % target)
changed = 0
for index in target:
    tampered[4 * index:4 * index + 4] = (0x7FC00001).to_bytes(4, "big")
    changed += 1
hdu.data = bytes(tampered)
tampered_path = os.path.join(DERIVED, "float32_specials.nan-repayload.fits")
open(tampered_path, "wb").write(forced_candidate(hdu))
back = np.asarray(fits.getdata(tampered_path, 1))
same_bits = back.astype(">f4").tobytes() == expected.tobytes()
equal_nan = np.array_equal(back, expected, equal_nan=True)
print("    read back: identical bytes=%s  equal_nan=%s  equal=%s"
      % (same_bits, equal_nan, np.array_equal(back, expected)))
problems = oracle.check_rewritten(tampered_path, original_bytes, case_for())
print("    gate: %d problem(s) on a file whose NaN payload was changed" % len(problems))
for problem in problems:
    print("    -", problem)
experiment.note("nan-repayload", pixels=target, changed=changed,
                bytes_identical=same_bits, equal_nan=equal_nan, problems=problems)

# ---- 4. who keeps the bits: four writers, decoded by funpack ---------------
astropy_path = os.path.join(DERIVED, "float32_specials.astropy-gzip2.fits")
with fits.HDUList([fits.PrimaryHDU(),
                   fits.CompImageHDU(data=expected.astype(">f4"),
                                     compression_type="GZIP_2",
                                     quantize_level=0)]) as hdul:
    hdul.writeto(astropy_path, overwrite=True)

g2_path = os.path.join(DERIVED, "float32_specials.e14-fpack-g2.fits")
if os.path.exists(g2_path):
    os.remove(g2_path)
experiment.fpack("fpack-g2", original, g2_path,
                 extra=("-g2", "-q", "0", "-F", "-O", g2_path))

WRITERS = [
    ("tzim", tzim_candidate),
    ("fpack -g -q 0", gzip1),
    ("fpack -g2 -q 0", g2_path),
    ("astropy GZIP_2 q=0", astropy_path),
]

table = []
for name, path in WRITERS:
    decode = os.path.join(DERIVED, "E14-%s.decoded.fits" % name.replace(" ", ""))
    if os.path.exists(decode):
        os.remove(decode)
    done = experiment.funpack("funpack-" + name.replace(" ", ""), path, decode)
    with fits.open(decode) as reopened:
        image = [i for i, hdu in enumerate(reopened) if hdu.data is not None][0]
    got = np.asarray(fits.getdata(decode, image)).astype(">f4")
    before = expected.view(">u4").ravel()
    after = got.view(">u4").ravel()
    differ = np.nonzero(before != after)[0]
    categories = {"nonfinite": 0, "denormal": 0, "signed zero": 0, "other": 0}
    for index in differ:
        source, decoded = int(before[index]), int(after[index])
        if (source & 0x7F800000) == 0x7F800000:
            categories["nonfinite"] += 1
        elif (source & 0x7F800000) == 0:
            if (source & 0x7FFFFFFF) == 0:
                categories["signed zero"] += 1
            else:
                categories["denormal"] += 1
        else:
            categories["other"] += 1
    row = {"writer": name, "exit": done["exit"], "pixels": int(before.size),
           "differing": len(differ), "categories": categories,
           "example": ["0x%08X -> 0x%08X" % (int(before[i]), int(after[i]))
                       for i in differ[:4]]}
    table.append(row)
    print("    %-20s funpack exit=%s  differing pixels %d/%d  %s"
          % (name, done["exit"], len(differ), before.size, categories))
experiment.note("bit-fidelity", rows=table)

experiment.save()
