#!/usr/bin/env python3
"""E10: F-05 — the scaling refusal depends on how the card is formatted.

Two inputs:
  bzero_float.fits      BSCALE = 1, BZERO = 32768.0   (the uint16 convention)
  bscale_two_five.fits  BSCALE = 2.5, BZERO = -100.0  (a genuine rescaling)

The transcribed `decide()` parses both cards with `parse::<i64>`; "32768.0" and
"2.5" both fail, so `unwrap_or(1)`/`unwrap_or(0)` make them look like the
identity and the HDU is tiled. The candidate is then checked with real CFITSIO:
is it legal, does it reconstruct, and do the *values* survive?
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
FIXTURES = os.path.join(BUNDLE, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
EVIDENCE = os.path.join(BUNDLE, "04-evidence")
sys.path.insert(0, HERE)
import model  # noqa: E402
import reader_model  # noqa: E402
from harness import (Experiment, array_bytes, card_diff, cards_of,  # noqa: E402
                     header_of, headers_of)

os.makedirs(DERIVED, exist_ok=True)
experiment = Experiment("E10-scaling",
                        "F-05: does a floating-point scaling card bypass the refusal, and "
                        "is the data still intact?")
summary = []

for name in ("bzero_float", "bscale_two_five"):
    original = os.path.join(FIXTURES, name + ".fits")
    decision = reader_model.outcome(original)
    experiment.note("decision-" + name, **decision)

    header = header_of(original)
    cards = [header[offset:offset + 80] for offset in range(0, len(header), 80)]
    cards = [card for card in cards if card[:8].rstrip() != b"END" and card.strip()]
    text = header.decode("ascii")
    bitpix = int(text.split("BITPIX  =")[1].split()[0])
    naxis = int(text.split("NAXIS   =")[1].split()[0])
    axes = [int(text[text.index("NAXIS%d  =" % axis):][:80].split("=")[1].split()[0])
            for axis in range(1, naxis + 1)]
    hdu = model.Hdu(cards, array_bytes(original), "Primary", bitpix, axes)
    out = bytearray()
    model.empty_primary(out)
    model.write_tiled(hdu, out)
    candidate = os.path.join(DERIVED, name + ".tzim-candidate.fits")
    with open(candidate, "wb") as handle:
        handle.write(out)

    table_cards = [card.decode("ascii").rstrip() for card in cards_of(headers_of(candidate)[1])]
    experiment.note("table-cards-" + name, cards=table_cards)
    verify = experiment.fitsverify("fitsverify-" + name, candidate)
    reconstructed = os.path.join(DERIVED, name + ".reconstructed.fits")
    unpack = experiment.funpack("funpack-" + name, candidate, reconstructed)

    row = {
        "fixture": name,
        "transcribed_decision": decision["status"],
        "fitsverify_exit": verify["exit"],
        "funpack_exit": unpack["exit"],
        "has_zpairs": sum(1 for card in table_cards if card.startswith(("BSCALE", "BZERO"))),
        "scaling_cards_in_table": [card for card in table_cards
                                   if card.startswith(("BSCALE", "BZERO"))],
        "array_identical": (array_bytes(original) == array_bytes(reconstructed))
        if os.path.exists(reconstructed) else None,
    }
    if os.path.exists(reconstructed):
        row["header_diff"] = card_diff(header_of(original), header_of(reconstructed))
    summary.append(row)

experiment.note("summary", rows=summary)
experiment.save()

with open(os.path.join(EVIDENCE, "E10-summary.json"), "w") as handle:
    json.dump(summary, handle, indent=2)
    handle.write("\n")

for row in summary:
    print("%-18s decision=%-14s verify=%s funpack=%s array==%s" % (
        row["fixture"], row["transcribed_decision"], row["fitsverify_exit"],
        row["funpack_exit"], row["array_identical"]))
    for card in row["scaling_cards_in_table"]:
        print("    table carries:", card)
    for diff in row.get("header_diff", []):
        print("    header diff:", diff["kind"], diff["keyword"])

# Values as CFITSIO/astropy sees them, for every pair.
probe = (
    "import sys\n"
    "import numpy as np\n"
    "from astropy.io import fits\n"
    "for path in sys.argv[1:]:\n"
    "    with fits.open(path) as hdul:\n"
    "        hdu = next(h for h in hdul if h.data is not None)\n"
    "        data = np.asarray(hdu.data)\n"
    "        print(path)\n"
    "        print('  dtype', data.dtype, 'shape', data.shape)\n"
    "        print('  first 6:', data.ravel()[:6].tolist())\n"
    "        print('  BSCALE', hdu.header.get('BSCALE'), 'BZERO', hdu.header.get('BZERO'))\n"
)
argv = [sys.executable, "-c", probe]
for name in ("bzero_float", "bscale_two_five"):
    argv.append(os.path.join(FIXTURES, name + ".fits"))
    argv.append(os.path.join(DERIVED, name + ".reconstructed.fits"))
experiment.run("astropy-values", argv)
experiment.save()
