#!/usr/bin/env python3
"""E07: the header tzim reconstructs vs the original, and vs the reference.

`funpack -C` of a tzim candidate and `funpack -C` of an `fpack` file are compared
with the *original* header at the 80-column level. This is F-03 (tzim) and the
positive control (reference) in one place.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
FIXTURES = os.path.join(BUNDLE, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
EVIDENCE = os.path.join(BUNDLE, "04-evidence")
sys.path.insert(0, HERE)
from harness import card_diff, header_of  # noqa: E402

TRACES = [
    ("int16_primary", "fpack", os.path.join(DERIVED, "int16_primary.fpack.funpack.with-C.fits")),
    ("int16_primary", "tzim", os.path.join(DERIVED, "int16_primary.reconstructed.fits")),
    ("float32_specials", "fpack", os.path.join(DERIVED, "float32_specials.fpack.funpack.with-C.fits")),
    ("float32_specials", "tzim", os.path.join(DERIVED, "float32_specials.reconstructed.fits")),
    ("extend_f_primary", "tzim", os.path.join(DERIVED, "extend_f_primary.reconstructed.fits")),
]

report = []
for name, trace, rebuilt in TRACES:
    original = os.path.join(FIXTURES, name + ".fits")
    if not os.path.exists(rebuilt):
        report.append({"fixture": name, "trace": trace, "error": "missing " + rebuilt})
        continue
    diffs = card_diff(header_of(original), header_of(rebuilt))
    report.append({"fixture": name, "trace": trace, "diff": diffs,
                   "header_byte_identical": not diffs})
    print("=== %s / %s: %d difference(s) ===" % (name, trace, len(diffs)))
    for diff in diffs:
        print("  %-9s %-8s original=%r" % (diff["kind"], diff["keyword"],
                                           diff["original"]))
        print("  %-9s %-8s rebuilt =%r" % ("", "", diff["rebuilt"]))
    print()

with open(os.path.join(EVIDENCE, "E07-headerdiff.json"), "w") as handle:
    json.dump({"experiment": "E07-headerdiff",
               "question": "What exactly does each reconstruction lose or invent?",
               "traces": report}, handle, indent=2)
    handle.write("\n")
print("->", os.path.join(EVIDENCE, "E07-headerdiff.json"))
