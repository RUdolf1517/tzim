#!/usr/bin/env python3
"""A line-by-line transcription of the *writer* in src/formats/fits.rs @ 5dd45b3.

This is NOT a run of the shipped binary and NOT the Rust code. The sandbox has no
Rust toolchain (`cargo`/`rustc` absent, static.rust-lang.org unreachable), so this
module transcribes the Rust functions that matter for the file format and lets
real CFITSIO (fitsverify / fpack / funpack) tell us what such a file *is*.

Transcribed (Rust line numbers at 5dd45b38412ffb762a1fc380bd291351c9e6601e):

  assemble()          fits.rs:184-197   card formatting
  numeric_card()      fits.rs:164-166
  boolean_card()      fits.rs:169-172
  string_card()       fits.rs:174-182
  write_header()      fits.rs:768-782   (cards + END + space padding to 2880)
  empty_primary()     fits.rs:1010-1021
  shuffle()           fits.rs:549-559
  gzip_member()       fits.rs:586-590   (flate2 GzEncoder, level 9)
  write_tiled()       fits.rs:652-800
  structural()        fits.rs:452-470
  optimize()          fits.rs:804-850   (image HDUs only, as the fixtures are)

**Known, deliberate difference:** the Rust writer compresses with `flate2`
(miniz_oxide); this transcription uses Python's zlib. Both produce RFC 1952
members and both are level 9, but the *compressed bytes* differ. Every claim made
from this module is therefore about the FITS structure (cards, descriptors, heap
layout, codec choice, permutation), not about byte identity of the tzim output.
The bundle says so wherever a number depends on it.
"""

RECORD = 2880
CARD = 80


# --- fits.rs:184-197 -------------------------------------------------------
def assemble(head: str, comment: str) -> bytes:
    out = bytearray(b" " * CARD)
    hb = head.encode("ascii")
    used = min(len(hb), CARD)
    out[:used] = hb[:used]
    if comment:
        start = min(max(used, 30), CARD)
        text = (" / " + comment).encode("ascii")
        take = min(len(text), CARD - start)
        out[start:start + take] = text[:take]
    return bytes(out)


# --- fits.rs:164-182 -------------------------------------------------------
def numeric_card(keyword: str, value: int, comment: str = "") -> bytes:
    return assemble("%-8s= %20d" % (keyword, value), comment)


def boolean_card(keyword: str, value: bool, comment: str = "") -> bytes:
    return assemble("%-8s= %20s" % (keyword, "T" if value else "F"), comment)


def string_card(keyword: str, value: str, comment: str = "") -> bytes:
    return assemble("%-8s= '%s'" % (keyword, value), comment)


# --- fits.rs:768-782 -------------------------------------------------------
def write_header(out: bytearray, cards) -> None:
    from_ = len(out)
    for card in cards:
        out += card
    out += assemble("END", "")
    padded = (len(out) - from_ + RECORD - 1) // RECORD * RECORD
    out += b" " * (from_ + padded - len(out))


# --- fits.rs:1010-1021 -----------------------------------------------------
def empty_primary(out: bytearray) -> None:
    write_header(out, [
        boolean_card("SIMPLE", True, "conforms to FITS standard"),
        numeric_card("BITPIX", 8, "array data type"),
        numeric_card("NAXIS", 0, "number of array dimensions"),
        boolean_card("EXTEND", True, ""),
    ])


# --- fits.rs:549-559 -------------------------------------------------------
def shuffle(samples: bytes, per_sample: int) -> bytes:
    count = len(samples) // per_sample
    out = bytearray(len(samples))
    for byte in range(per_sample):
        for sample in range(count):
            out[byte * count + sample] = samples[sample * per_sample + byte]
    return bytes(out)


# --- fits.rs:586-590 -------------------------------------------------------
def gzip_member(payload: bytes) -> bytes:
    import gzip, io
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=9, mtime=0) as f:
        f.write(payload)
    return buf.getvalue()


# --- fits.rs:452-470 -------------------------------------------------------
_STRUCTURAL_EXACT = {
    "SIMPLE", "XTENSION", "BITPIX", "NAXIS", "PCOUNT", "GCOUNT", "EXTEND",
    "TFIELDS", "THEAP", "EXTNAME", "ZIMAGE", "ZSIMPLE", "ZTENSION", "ZBITPIX",
    "ZNAXIS", "ZPCOUNT", "ZGCOUNT", "ZCMPTYPE", "ZNAME1", "ZVAL1",
}


def structural(keyword: str) -> bool:
    if keyword in _STRUCTURAL_EXACT:
        return True
    for prefix in ("NAXIS", "ZNAXIS", "ZTILE", "TTYPE", "TFORM"):
        rest = keyword[len(prefix):]
        if keyword.startswith(prefix) and rest and rest.isdigit():
            return True
    return False


def keyword(card: bytes) -> str:
    return card[:8].decode("ascii").rstrip(" ")


class Hdu:
    """The fields write_tiled() and decide_image() read."""

    def __init__(self, cards, data, kind, bitpix, axes):
        self.cards = cards
        self.data = data
        self.kind = kind          # 'Primary' | 'ImageExt'
        self.bitpix = bitpix
        self.axes = axes

    def text(self, keyword_):
        for card in self.cards:
            if card[:8].decode("ascii").rstrip() == keyword_:
                field = card[10:30].decode("ascii").rstrip()
                field = field.lstrip()
                if not field.startswith("'"):
                    return None
                rest = field[1:]
                end = rest.rfind("'")
                return rest[:end] if end >= 0 else None
        return None


# --- fits.rs:652-800 -------------------------------------------------------
def write_tiled(hdu: Hdu, out: bytearray) -> None:
    per_sample = abs(hdu.bitpix) // 8
    first_axis = hdu.axes[0]
    tile_bytes = first_axis * per_sample
    tiles = 1
    for axis in hdu.axes[1:]:
        tiles *= axis
    assert tile_bytes * tiles == len(hdu.data), (tile_bytes, tiles, len(hdu.data))

    floating = hdu.bitpix < 0
    codec = "GZIP_2" if floating else "GZIP_1"

    heap = bytearray()
    rows = []
    for i in range(tiles):
        tile = hdu.data[i * tile_bytes:(i + 1) * tile_bytes]
        member = gzip_member(shuffle(tile, per_sample) if floating else tile)
        rows.append((len(member), len(heap)))
        heap += member
    longest = max((length for length, _ in rows), default=0)

    cards = [
        string_card("XTENSION", "BINTABLE", "binary table extension"),
        numeric_card("BITPIX", 8, "array data type"),
        numeric_card("NAXIS", 2, "number of array dimensions"),
        numeric_card("NAXIS1", 8, "width of table in bytes"),
        numeric_card("NAXIS2", tiles, "number of rows in table"),
        numeric_card("PCOUNT", len(heap), "number of group parameters"),
        numeric_card("GCOUNT", 1, "number of groups"),
        numeric_card("TFIELDS", 1, "number of fields in each row"),
        string_card("TTYPE1", "COMPRESSED_DATA", ""),
        string_card("TFORM1", "1PB(%d)" % longest, ""),
        boolean_card("ZIMAGE", True, "extension contains compressed image"),
    ]
    if hdu.kind == "Primary":
        cards.append(boolean_card("ZSIMPLE", True, ""))
    else:
        cards.append(string_card("ZTENSION", "IMAGE", "Image extension"))
    cards += [
        numeric_card("ZBITPIX", hdu.bitpix, "array data type"),
        numeric_card("ZNAXIS", len(hdu.axes), "number of array dimensions"),
    ]
    for index, axis in enumerate(hdu.axes):
        cards.append(numeric_card("ZNAXIS%d" % (index + 1), axis, ""))
    present = {keyword(card) for card in hdu.cards}
    if "PCOUNT" in present:
        cards.append(numeric_card("ZPCOUNT", 0, "number of parameters"))
    if "GCOUNT" in present:
        cards.append(numeric_card("ZGCOUNT", 1, "number of groups"))
    cards.append(numeric_card("ZTILE1", first_axis, "size of tiles to be compressed"))
    for index in range(2, len(hdu.axes) + 1):
        cards.append(numeric_card("ZTILE%d" % index, 1, "size of tiles to be compressed"))
    cards.append(string_card("ZCMPTYPE", codec, "compression algorithm"))
    if floating:
        cards.append(string_card("ZNAME1", "NOISEBIT",
                                 "floating point quantization level"))
        cards.append(numeric_card("ZVAL1", 0,
                                  "floating point quantization level"))
    extname = next((c for c in hdu.cards if keyword(c) == "EXTNAME"), None)
    if extname is not None:
        cards.append(extname)
    else:
        cards.append(string_card("EXTNAME", "COMPRESSED_IMAGE",
                                 "name of this binary table extension"))
    for card in hdu.cards:
        if not structural(keyword(card)):
            cards.append(card)

    write_header(out, cards)
    data_start = len(out)
    for length, offset in rows:
        out += length.to_bytes(4, "big") + offset.to_bytes(4, "big")
    out += heap
    padded = (len(out) - data_start + RECORD - 1) // RECORD * RECORD
    out += b"\x00" * (data_start + padded - len(out))


# --- fits.rs:804-850 -------------------------------------------------------
def optimize(hdus) -> bytes:
    """The candidate, or None when it would not be strictly smaller."""
    out = bytearray()
    total = 0
    for index, hdu in enumerate(hdus):
        if hdu.kind in ("Primary", "ImageExt"):
            if index == 0:
                empty_primary(out)
            write_tiled(hdu, out)
        else:                        # Decision::Keep
            raise NotImplementedError("this transcription only handles image HDUs")
        total += len(hdu.cards) * CARD + len(hdu.data)
    total += RECORD * len(hdus)      # headers padded
    if len(out) >= total:
        return None
    return bytes(out)


# --- fixture helper, not part of fits.rs -----------------------------------
def header_bytes(cards) -> bytes:
    out = bytearray()
    write_header(out, cards)
    return bytes(out)


def data_block(data: bytes, start_aligned: bool = True) -> bytes:
    out = bytearray(data)
    padded = (len(out) + RECORD - 1) // RECORD * RECORD
    out += b"\x00" * (padded - len(out))
    return bytes(out)


class Image:
    """An image HDU assembled from explicit cards plus a raw big-endian array."""

    def __init__(self, cards, data, kind, bitpix, axes):
        self.hdu = Hdu(cards, data, kind, bitpix, axes)
        self.cards = cards
        self.data = data

    def file(self) -> bytes:
        return header_bytes(self.cards) + data_block(self.data)

    def size(self) -> int:
        return len(header_bytes(self.cards)) + len(data_block(self.data))
