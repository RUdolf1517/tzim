#!/usr/bin/env python3
"""E06: the reference trace — fpack -> funpack — on the same input.

This is the positive control (report control C-4). If the reference pair cannot
reproduce the original header byte for byte, then a red diff says nothing about
tzim. Run with and without `-C` to show what `funpack` adds on its own.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
FIXTURES = os.path.join(BUNDLE, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
EVIDENCE = os.path.join(BUNDLE, "04-evidence")
sys.path.insert(0, HERE)
from harness import Experiment, array_bytes, card_diff, header_of  # noqa: E402

os.makedirs(DERIVED, exist_ok=True)
experiment = Experiment("E06-reference",
                        "Does CFITSIO's own writer+reader reproduce the original "
                        "header and array? (positive control)")
rows = []

for name in ("int16_primary", "float32_specials"):
    original = os.path.join(FIXTURES, name + ".fits")
    packed = os.path.join(DERIVED, name + ".fpack.fits")
    # -g: gzip tile compression, which is the codec tzim writes.
    # -q 0 for floats: no quantization, i.e. GZIP_2 without ZSCALE/ZZERO. This is
    # the lossless float path fpack documents; the default q=4 quantizes, which
    # would make the reference lossy and not comparable.
    flags = ["-g", "-q", "0"] if name.startswith("float") else ["-g"]
    experiment.fpack("fpack-gzip-" + name, original, packed,
                     extra=(*flags, "-O", packed))
    experiment.fitsverify("fitsverify-fpack-" + name, packed)

    for flag, tag in (("-C", "with-C"), (None, "no-C")):
        rebuilt = os.path.join(DERIVED, "%s.fpack.funpack.%s.fits" % (name, tag))
        if os.path.exists(rebuilt):
            os.remove(rebuilt)
        if flag:
            experiment.funpack("funpack-%s-%s" % (name, tag), packed, rebuilt)
        else:
            experiment.funpack("funpack-%s-%s" % (name, tag), packed, rebuilt,
                               extra=("-O", rebuilt))
        row = {"fixture": name, "flag": flag, "reconstructed": rebuilt,
               "exists": os.path.exists(rebuilt)}
        if os.path.exists(rebuilt):
            row["header_byte_identical"] = header_of(original) == header_of(rebuilt)
            row["diff"] = card_diff(header_of(original), header_of(rebuilt))
            row["array_identical"] = array_bytes(original)[:len(array_bytes(original))] == \
                array_bytes(rebuilt)[:len(array_bytes(original))]
        rows.append(row)

experiment.note("summary", rows=rows)
experiment.save()
with open(os.path.join(EVIDENCE, "E06-summary.json"), "w") as handle:
    json.dump(rows, handle, indent=2)
    handle.write("\n")

for row in rows:
    print("%-18s funpack %-6s header identical=%-5s diffs=%d" % (
        row["fixture"], row["flag"] or "default",
        row.get("header_byte_identical"), len(row.get("diff", []))))
