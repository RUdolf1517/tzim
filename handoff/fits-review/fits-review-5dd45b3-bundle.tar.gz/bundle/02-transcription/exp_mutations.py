#!/usr/bin/env python3
"""E08: what does fitsverify actually notice?

Every mutation is applied to one copy of the int16 candidate. For each: run
`fitsverify -l` and `funpack -C`, record stdout/stderr/exit, and whether funpack
produced an output file.

This is the experiment behind report §7.1/§7.2: a green fitsverify is not
evidence about the tile data.
"""
import json
import os
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
DERIVED = os.path.join(BUNDLE, "01-fixtures", "derived")
EVIDENCE = os.path.join(BUNDLE, "04-evidence")
sys.path.insert(0, HERE)
from harness import Experiment, CFITSIO_ENV, FUNPACK, array_bytes, header_of  # noqa: E402

BASE = os.path.join(DERIVED, "int16_primary.tzim-candidate.fits")
base = bytearray(open(BASE, "rb").read())


def table_data_start(blob):
    """Offset of the BINTABLE's data: header records, then record padding."""
    start = 2880                             # past the empty primary from empty_primary()
    offset = start
    while True:
        for within in range(0, 2880, 80):
            if blob[offset + within:offset + within + 8].rstrip() == b"END":
                header_len = offset + within + 80 - start
                return start + (header_len + 2879) // 2880 * 2880
        offset += 2880


data_start = table_data_start(base)           # table data begins after the BINTABLE header
member = bytes(base).find(b"\x1f\x8b\x08", data_start)
row0 = struct.unpack(">II", bytes(base[data_start:data_start + 8]))
rows = struct.unpack(">II", bytes(base[data_start + 8:data_start + 16]))
first_length, first_offset = row0

experiment = Experiment("E08-mutations",
                        "Which corruptions does fitsverify catch, and which does only "
                        "funpack catch?")
experiment.note("layout", header_bytes=data_start, first_member=member,
                row0_length=first_length, row0_offset=first_offset,
                second_row_length=rows[0], second_row_offset=rows[1])


def card_offset(keyword):
    index = bytes(base).find(keyword.encode("ascii"))
    assert index >= 0, keyword
    return index


def mutate(name, offset, replacement, description):
    blob = bytearray(base)
    blob[offset:offset + len(replacement)] = replacement
    path = os.path.join(DERIVED, "mutant-%s.fits" % name)
    with open(path, "wb") as handle:
        handle.write(blob)

    verify = experiment.fitsverify("fitsverify-" + name, path)
    rebuilt = os.path.join(DERIVED, "mutant-%s.unpacked.fits" % name)
    if os.path.exists(rebuilt):
        os.remove(rebuilt)
    # 30 s: one mutant makes funpack spin (recorded as a killed run, not a verdict)
    unpack = experiment.run("funpack-" + name,
                            [FUNPACK, "-C", "-O", rebuilt, path],
                            env=CFITSIO_ENV, timeout=30)
    # a file can be produced and still be wrong: compare the pixels with the original
    if os.path.exists(rebuilt):
        data_matches = array_bytes(rebuilt) == array_bytes(
            os.path.join(BUNDLE, "01-fixtures", "int16_primary.fits"))
    else:
        data_matches = None
    row = {
        "mutation": name,
        "description": description,
        "offset": offset,
        "fitsverify_exit": verify["exit"],
        "fitsverify_summary": next((line.strip() for line in verify["stdout"].splitlines()
                                    if "Verification found" in line), ""),
        "funpack_exit": unpack["exit"],
        "funpack_produced_file": os.path.exists(rebuilt),
        "reconstructed_array_matches_original": data_matches,
        "funpack_message": " / ".join(line.strip() for line in
                                      (unpack["stdout"] + unpack["stderr"]).splitlines()[-3:]
                                      if line.strip()),
    }
    print("%-22s verify exit=%-2d funpack exit=%-4d file=%-5s data_matches=%s" % (
        name, row["fitsverify_exit"], row["funpack_exit"],
        row["funpack_produced_file"], data_matches))
    return row


rows_out = []
rows_out.append(mutate("baseline", 0, b"", "unmodified candidate"))
for delta in (200, 120, 60, 40):
    rows_out.append(mutate("tile_byte_%d" % delta, member + delta,
                           bytes([base[member + delta] ^ 0xFF]),
                           "one byte inside the first gzip member's DEFLATE data "
                           "(offset +%d)" % delta))
rows_out.append(mutate("tile_crc_flipped", member + first_length - 8,
                       bytes([base[member + first_length - 8] ^ 0xFF]),
                       "the CRC-32 field of the first member's trailer"))
rows_out.append(mutate("tile_isize_flipped", member + first_length - 4,
                       bytes([base[member + first_length - 4] ^ 0xFF]),
                       "the ISIZE field of the first member's trailer"))
rows_out.append(mutate("gzip_method_byte", member + 2, b"\x09",
                       "gzip CM byte 08 ('deflate') -> 09 (reserved)"))
rows_out.append(mutate("row0_length_halved", data_start + 3,
                       b"\x00\x00\x00"[:0] + bytes([first_length // 2 & 0xFF]),
                       "the low byte of row 0's length descriptor"))
rows_out.append(mutate("ztile1_halved", card_offset("ZTILE1  =") + 29, b"40",
                       "ZTILE1 80 -> 40: tile geometry no longer covers the array"))
rows_out.append(mutate("zsimple_false", card_offset("ZSIMPLE =") + 29, b"F",
                       "ZSIMPLE T -> F on a compressed primary"))
rows_out.append(mutate("zcmptype_rice", card_offset("ZCMPTYPE= '") + 11, b"RICE_1",
                       "ZCMPTYPE GZIP_1 -> RICE_1 while the heap is gzip"))
rows_out.append(mutate("zbitpix_negative", card_offset("ZBITPIX =") + 29, b"-32",
                       "ZBITPIX 16 -> -32 while the samples are int16"))
rows_out.append(mutate("naxis2_less", card_offset("NAXIS2  =") + 29, b"127",
                       "NAXIS2 128 -> 127 (one row descriptor missing)"))
rows_out.append(mutate("znaxis2_less", card_offset("ZNAXIS2 =") + 29, b"127",
                       "ZNAXIS2 128 -> 127"))
rows_out.append(mutate("extname_renamed", card_offset("EXTNAME = '") + 11,
                       b"MY_IMAGE        ", "EXTNAME changed (should be harmless)"))
rows_out.append(mutate("ztile2_two", card_offset("ZTILE2  =") + 29, b"2",
                       "ZTILE2 1 -> 2: the table claims tiles of two rows"))
rows_out.append(mutate("znaxis1_halved", card_offset("ZNAXIS1 =") + 29, b"128",
                       "ZNAXIS1 256 -> 128: the image is declared half as wide as the tiles"))

truncated = bytes(base[:len(base) - 2880])
path = os.path.join(DERIVED, "mutant-truncated.fits")
open(path, "wb").write(truncated)
verify = experiment.fitsverify("fitsverify-truncated", path)
rebuilt = os.path.join(DERIVED, "mutant-truncated.unpacked.fits")
if os.path.exists(rebuilt):
    os.remove(rebuilt)
unpack = experiment.funpack("funpack-truncated", path, rebuilt)
data_matches = None
if os.path.exists(rebuilt):
    data_matches = array_bytes(rebuilt) == array_bytes(
        os.path.join(BUNDLE, "01-fixtures", "int16_primary.fits"))
rows_out.append({
    "mutation": "truncated", "description": "last 2880-byte record removed",
    "offset": len(base) - 2880,
    "fitsverify_exit": verify["exit"],
    "fitsverify_summary": next((line.strip() for line in verify["stdout"].splitlines()
                                if "Verification found" in line), ""),
    "funpack_exit": unpack["exit"],
    "funpack_produced_file": os.path.exists(rebuilt),
    "reconstructed_array_matches_original": data_matches,
    "funpack_message": " / ".join(line.strip() for line in
                                  (unpack["stdout"] + unpack["stderr"]).splitlines()[-3:]
                                  if line.strip()),
})
print("%-22s verify exit=%-2d funpack exit=%-4d data_matches=%s" % (
    "truncated", verify["exit"], unpack["exit"], data_matches))

experiment.note("table", rows=rows_out)
experiment.save()
with open(os.path.join(EVIDENCE, "E08-summary.json"), "w") as handle:
    json.dump(rows_out, handle, indent=2)
    handle.write("\n")
