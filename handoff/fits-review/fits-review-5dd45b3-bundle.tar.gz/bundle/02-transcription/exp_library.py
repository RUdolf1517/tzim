#!/usr/bin/env python3
"""E15: is the bit loss in libcfitsio, or in the `fpack` utility?

Three probes on the same eight float32 bit patterns (denormal, largest negative
denormal, -0.0, qNaN payload 1, +inf, -inf, 1.0, FLT_MAX):

  1. libcfitsio's own public API (compiled C, linked against the reviewed
     library): write a tile-compressed GZIP_2 HDU, read it back;
  2. `fpack -g2 -q 0` on the same eight pixels, then `funpack`;
  3. `fitsverify` on both files.

The point is to name the layer. A review that blames "CFITSIO" for what `fpack`
does would be wrong if probe 1 is exact.
"""
import os
import sys

import numpy as np
from astropy.io import fits

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
TOOLS = os.path.join(BUNDLE, "05-tools")
DERIVED = os.path.join(BUNDLE, "01-fixtures", "derived")
SOURCE = os.path.join(TOOLS, "cfitsio-roundtrip.c")
BINARY = "/tmp/cfitsio-roundtrip"
sys.path.insert(0, HERE)
from harness import CFITSIO_ENV, Experiment  # noqa: E402

PATTERNS = [0x00000001, 0x807FFFFF, 0x80000000, 0x7FC00001,
            0x7F800000, 0xFF800000, 0x3F800000, 0x7F7FFFFF]

experiment = Experiment("E15-library-vs-fpack",
                        "Does libcfitsio itself lose float bits, or only the fpack utility?")

# ---- 1. libcfitsio through its own API -------------------------------------
experiment.run("compile", ["gcc", "-O0", "-I/tmp/cfitsio-src",
                           "-o", BINARY, SOURCE,
                           "-L/tmp/cfitsio-src/.libs", "-lcfitsio",
                           "-Wl,-rpath,/tmp/cfitsio-src/.libs"])
run = experiment.run("roundtrip", [BINARY], env=CFITSIO_ENV)
print(run["stdout"].strip())

library_file = "/tmp/cfitsio-roundtrip.fits"
raw = open(library_file, "rb").read()
codec = None
second = raw[2880:2880 + 2880]
for offset in range(0, len(second), 80):
    card = second[offset:offset + 80].decode("ascii", "replace")
    if card.startswith("ZCMPTYPE"):
        codec = card[10:30].strip()
print("libcfitsio wrote ZCMPTYPE=%s" % codec)
experiment.note("libcfitsio", codec=codec, exit=run["exit"], identical="yes" in run["stdout"])
experiment.fitsverify("fitsverify-libcfitsio", library_file)

# ---- 2. the same eight pixels through fpack ---------------------------------
source_path = os.path.join(DERIVED, "float8.fits")
array = np.frombuffer(b"".join(value.to_bytes(4, "big") for value in PATTERNS),
                      dtype=">f4").reshape(1, 8)
fits.PrimaryHDU(data=array).writeto(source_path, overwrite=True)

compressed = os.path.join(DERIVED, "float8.fpack-g2.fits")
if os.path.exists(compressed):
    os.remove(compressed)
experiment.fpack("fpack-g2", source_path, compressed,
                 extra=("-g2", "-q", "0", "-F", "-O", compressed))
rebuilt = os.path.join(DERIVED, "float8.fpack-g2.decoded.fits")
if os.path.exists(rebuilt):
    os.remove(rebuilt)
experiment.funpack("funpack-g2", compressed, rebuilt)

back = np.asarray(fits.getdata(rebuilt, 0)).astype(">f4")
before_bits = [int(value) for value in np.frombuffer(array.tobytes(), dtype=">u4")]
after_bits = [int(value) for value in np.frombuffer(back.tobytes(), dtype=">u4")]
print("\nfpack round trip:")
for index, (was, now) in enumerate(zip(before_bits, after_bits)):
    print("  [%d] 0x%08X -> 0x%08X %s" % (index, was, now, "" if was == now else "CHANGED"))
experiment.note("fpack", before=before_bits, after=after_bits,
                changed=sum(1 for was, now in zip(before_bits, after_bits) if was != now))

experiment.save()
