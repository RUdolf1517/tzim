#!/usr/bin/env python3
"""E13: who writes ZNAME1='NOISEBIT' / ZVAL1=0 for a float image?

Three writers on the same float32 array:
  tzim (transcription)   — writes the two cards unconditionally for BITPIX < 0
  fpack -g   -q 0        — GZIP_1, lossless (no quantization), no ZNAME/ZVAL
  fpack -g2  -q 0        — GZIP_2, lossless, no ZNAME/ZVAL
  astropy CompImageHDU(quantize_level=0, compression_type='GZIP_2')
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
FIXTURES = os.path.join(BUNDLE, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
sys.path.insert(0, HERE)
from harness import Experiment, cards_of, headers_of  # noqa: E402

experiment = Experiment("E13-znmae",
                        "Which writer emits ZNAME1='NOISEBIT'/ZVAL1=0 on a float image?")

PROBE = (
    "import sys\n"
    "from astropy.io import fits\n"
    "import numpy as np\n"
    "src, dst = sys.argv[1], sys.argv[2]\n"
    "with fits.open(src) as hdul:\n"
    "    hdu = hdul[0]\n"
    "    data = np.asarray(hdu.data)\n"
    "    out = fits.CompImageHDU(data=data, compression_type='GZIP_2',\n"
    "                            quantize_level=0)\n"
    "    out.writeto(dst, overwrite=True)\n"
    "    print('wrote', dst)\n"
)

source = os.path.join(FIXTURES, "float32_specials.fits")
astropy_out = os.path.join(DERIVED, "float32_specials.astropy.fits")
experiment.run("astropy-compress", [sys.executable, "-c", PROBE, source, astropy_out])

g2 = os.path.join(DERIVED, "float32_specials.fpack-g2.fits")
if os.path.exists(g2):
    os.remove(g2)
experiment.fpack("fpack-g2", source, g2, extra=("-g2", "-q", "0", "-F", "-O", g2))

CASES = [
    ("tzim", os.path.join(DERIVED, "float32_specials.tzim-candidate.fits")),
    ("fpack-g", os.path.join(DERIVED, "float32_specials.fpack.fits")),
    ("fpack-g2", g2),
    ("astropy", astropy_out),
]

report = []
for name, path in CASES:
    if not os.path.exists(path):
        report.append({"writer": name, "path": path, "missing": True})
        continue
    cards = [card.decode("ascii").rstrip() for card in cards_of(headers_of(path)[1])]
    interesting = [card for card in cards
                   if card.startswith(("ZCMPTYPE", "ZNAME", "ZVAL", "ZBITPIX"))]
    report.append({"writer": name, "path": path, "cards": interesting})
    print("%-10s %s" % (name, interesting))

experiment.note("writers", rows=report)

# Are the extra cards legal? fitsverify on each.
for name, path in CASES:
    if os.path.exists(path):
        experiment.fitsverify("fitsverify-" + name, path)

experiment.save()
