#!/usr/bin/env python3
"""E09: PR #73's own comparison functions, run on real CFITSIO output.

The gate script is imported unmodified from
`02-transcription/pr73-fits-heasarc.py` (verified against the PR head by sha256
in 05-tools/pr73-provenance.txt). Only its pure functions are used:
`parse`, `literal_card_diff`, `classify_diff`, `compare_arrays`.

Four traces:
  reference, funpack -C    expected: empty diff (positive control)
  tzim,      funpack -C    expected: the F-03 differences
  reference, funpack       expected: CHECKSUM/DATASUM invented by funpack
  tzim,      funpack       expected: the above plus F-03
"""
import importlib.util
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
FIXTURES = os.path.join(BUNDLE, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
EVIDENCE = os.path.join(BUNDLE, "04-evidence")
sys.path.insert(0, HERE)
from harness import Experiment  # noqa: E402

spec = importlib.util.spec_from_file_location("gate", os.path.join(HERE, "pr73-fits-heasarc.py"))
gate = importlib.util.module_from_spec(spec)
sys.modules["gate"] = gate
spec.loader.exec_module(gate)

experiment = Experiment("E09-gate",
                        "Would PR #73's comparison pass the reference writer, and does it "
                        "pass the transcribed writer?")

original = os.path.join(FIXTURES, "int16_primary.fits")
tzim_candidate = os.path.join(DERIVED, "int16_primary.tzim-candidate.fits")
fpack_candidate = os.path.join(DERIVED, "int16_primary.fpack.fits")

ref_no_c = os.path.join(DERIVED, "int16_primary.fpack.funpack.no-C.fits")
ref_with_c = os.path.join(DERIVED, "int16_primary.fpack.funpack.with-C.fits")
tzim_with_c = os.path.join(DERIVED, "int16_primary.reconstructed.fits")
tzim_no_c = os.path.join(DERIVED, "int16_primary.tzim.funpack.no-C.fits")

# All four are produced here, explicitly, so the trace name and the flag match.
for stale in (ref_no_c, ref_with_c, tzim_no_c, tzim_with_c):
    if os.path.exists(stale):
        os.remove(stale)
experiment.funpack("funpack-reference-no-C", fpack_candidate, ref_no_c,
                   extra=("-O", ref_no_c))
experiment.funpack("funpack-reference-with-C", fpack_candidate, ref_with_c,
                   extra=("-C", "-O", ref_with_c))
experiment.funpack("funpack-tzim-no-C", tzim_candidate, tzim_no_c,
                   extra=("-O", tzim_no_c))
experiment.funpack("funpack-tzim-with-C", tzim_candidate, tzim_with_c,
                   extra=("-C", "-O", tzim_with_c))

PAIRS = [
    ("reference-with-C", original, ref_with_c),
    ("tzim-with-C", original, tzim_with_c),
    ("reference-no-C", original, ref_no_c),
    ("tzim-no-C", original, tzim_no_c),
]

report = []
for label, before_path, after_path in PAIRS:
    before = gate.parse(open(before_path, "rb").read())
    after = gate.parse(open(after_path, "rb").read())
    if after and after[0].kind() == "PRIMARY" and not after[0].axes() and before[0].axes():
        after = after[1:]
    entries = []
    for index, (a, b) in enumerate(zip(before, after)):
        diffs = gate.literal_card_diff(a, b)
        entries.append({
            "hdu": index,
            "kind": a.kind(),
            "literal_card_diff": [
                dict(d, classification=gate.classify_diff(d)) for d in diffs
            ],
            "compare_arrays": gate.compare_arrays(a, b) if a.kind() in ("PRIMARY", "IMAGE") else None,
            "hdus_before": len(before),
            "hdus_after": len(after),
        })
    verdict = "green" if not any(e["literal_card_diff"] or (e["compare_arrays"] or [])
                                for e in entries) else "red"
    report.append({"trace": label, "verdict": verdict, "hdus": entries})
    print("%-18s %-5s  diffs=%d" % (label, verdict,
                                    sum(len(e["literal_card_diff"]) for e in entries)))

experiment.note("gate-runs", traces=report)
experiment.save()
with open(os.path.join(EVIDENCE, "E09-summary.json"), "w") as handle:
    json.dump(report, handle, indent=2)
    handle.write("\n")

for trace in report:
    if trace["trace"] in ("reference-with-C", "tzim-with-C"):
        print("\n=== %s ===" % trace["trace"])
        for hdu in trace["hdus"]:
            for diff in hdu["literal_card_diff"]:
                print("  %-9s %-8s original=%r rebuilt=%r [%s]" % (
                    diff["kind"], diff["keyword"], diff["original"],
                    diff["reconstructed"], diff["classification"]))
