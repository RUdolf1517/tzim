#!/usr/bin/env python3
"""E02 (fixtures) and E03 (are the inputs legal FITS?).

E03 is the load-bearing experiment for F-01 and F-02: `fitsverify` decides
whether the fixture is a legal FITS file. If it is, then a `failed` verdict from
tzim on it is a false refusal, not garbage-in.
"""
import hashlib
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Experiment  # noqa: E402

BUNDLE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIXTURES = os.path.join(BUNDLE, "01-fixtures")

FIXTURE_FILES = [
    "int16_primary.fits",
    "int8_primary.fits",
    "float32_specials.fits",
    "bzero_float.fits",
    "bscale_two_five.fits",
    "pcount_primary.fits",
    "random_groups.fits",
    "simple_f_empty.fits",
    "simple_f_data.fits",
    "extend_f_primary.fits",
]

# --- E02: build -----------------------------------------------------------------
build = Experiment("E02-fixtures", "The minimal inputs, byte for byte.")
build.run("make-fixtures", [sys.executable, os.path.join(FIXTURES, "make_fixtures.py")])
build.run("sha256", ["sha256sum", *[os.path.join(FIXTURES, name) for name in FIXTURE_FILES]])
build.run("sizes", ["bash", "-lc", "ls -l %s/*.fits" % FIXTURES])
build.save()

# --- E03: legality --------------------------------------------------------------
legal = Experiment("E03-legality",
                   "Does fitsverify accept each input? This is what makes a refusal "
                   "a *false* refusal.")
for name in FIXTURE_FILES:
    legal.fitsverify("fitsverify-" + name.replace(".fits", ""),
                     os.path.join(FIXTURES, name))
    legal.note(name, path=os.path.join(FIXTURES, name),
               sha256=hashlib.sha256(open(os.path.join(FIXTURES, name), "rb").read()).hexdigest())
legal.save()
