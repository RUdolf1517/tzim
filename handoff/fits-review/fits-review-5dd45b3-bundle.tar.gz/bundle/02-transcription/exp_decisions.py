#!/usr/bin/env python3
"""E04: what would tzim do with each fixture? (transcribed read path, no subprocess)

This is the transcription, not the binary: the answer is "what the transcribed
`scan()` + `decide()` return". `pipeline.rs:141-160` maps `Error::Parse` to
Status::Failed (exit 1) and `Error::Refused`/`Limit` to Status::Skipped (exit 0),
which is why the status column matters.
"""
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
FIXTURES = os.path.join(BUNDLE, "01-fixtures")
EVIDENCE = os.path.join(BUNDLE, "04-evidence")
sys.path.insert(0, HERE)
import reader_model  # noqa: E402

FILES = sorted(name for name in os.listdir(FIXTURES) if name.endswith(".fits"))
rows = []
for name in FILES:
    path = os.path.join(FIXTURES, name)
    try:
        outcome = reader_model.outcome(path)
    except Exception as error:                       # a transcription bug, not a verdict
        outcome = {"status": "transcription-error", "exit": None, "reason": repr(error)}
    rows.append({"file": name, "sha256": hashlib.sha256(open(path, "rb").read()).hexdigest(),
                 **outcome})
    print("%-24s %-14s exit=%-4s %s" % (name, outcome["status"], outcome["exit"],
                                        outcome.get("reason", "")))

# For the random-groups file, record the arithmetic behind the failure: what the
# transcription declares, and what FITS 4.0 section 6.2 says the file holds.
details = {}
path = os.path.join(FIXTURES, "random_groups.fits")
data = open(path, "rb").read()
header = reader_model.parse_header(data, 0)
bitpix, axes, declared = reader_model.declared_data_len(header)
groups = header.truth("GROUPS") is True
pcount = header.int("PCOUNT") or 0
gcount = header.int("GCOUNT") or 1
true_len = (abs(bitpix) // 8) * gcount * (pcount + (axes[1] if groups else
             __import__("math").prod(axes)))
details["random_groups"] = {
    "axes": axes, "groups": groups, "pcount": pcount, "gcount": gcount,
    "tzim_declared_data_len": declared,
    "fits_4_0_section_6_2_length": true_len,
    "next_hdu_offset_the_transcription_computes": 2880 + declared,
    "file_bytes": len(data),
}
print("random_groups: declared=%d true=%d (bitpix=%d axes=%s pcount=%d gcount=%d)" % (
    declared, true_len, bitpix, axes, pcount, gcount))

payload = {
    "experiment": "E04-decisions",
    "details": details,
    "question": "For each fixture: would the transcribed scan()/decide() of 5dd45b3 "
                "skip it (exit 0) or fail it (exit 1)?",
    "method": "transcription of src/formats/fits.rs, not the shipped binary",
    "rows": rows,
}
os.makedirs(EVIDENCE, exist_ok=True)
with open(os.path.join(EVIDENCE, "E04-decisions.json"), "w") as handle:
    json.dump(payload, handle, indent=2)
    handle.write("\n")
print("-> %s" % os.path.join(EVIDENCE, "E04-decisions.json"))
