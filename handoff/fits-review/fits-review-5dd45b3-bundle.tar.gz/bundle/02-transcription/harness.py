#!/usr/bin/env python3
"""Evidence harness: every external command is run once, and its stdout, stderr
and exit code are written to disk.

Layout produced under 04-evidence/:

  <experiment-id>/<seq>-<slug>.cmd      the exact argv, one element per line
  <experiment-id>/<seq>-<slug>.stdout   stdout, verbatim
  <experiment-id>/<seq>-<slug>.stderr   stderr, verbatim
  <experiment-id>/<seq>-<slug>.exit     exit code, one integer
  <experiment-id>.json                  all of the above, plus notes

Nothing is truncated and nothing is merged: a reader can reproduce any single
row of the report from one .cmd + .stdout + .stderr + .exit quadruple.
"""
import json
import os
import shlex
import subprocess
import time

BUNDLE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EVIDENCE = os.path.normpath(os.path.join(BUNDLE, "04-evidence"))

# The CFITSIO build. Outside the workspace on purpose (build artifact); it is
# reproduced by 05-tools/build-tools.sh at the SHA recorded in
# 05-tools/cfitsio-rev.txt.
CFITSIO_SRC = "/tmp/cfitsio-src"
CFITSIO_ENV = dict(os.environ, LD_LIBRARY_PATH=os.path.join(CFITSIO_SRC, ".libs"))
FITSVERIFY = os.path.join(CFITSIO_SRC, "fitsverify")
FPACK = os.path.join(CFITSIO_SRC, "fpack")
FUNPACK = os.path.join(CFITSIO_SRC, "funpack")


def slug(text):
    keep = [c if (c.isalnum() or c in "-_") else "-" for c in text]
    return "".join(keep).strip("-")[:60]


class Experiment:
    def __init__(self, identifier, question):
        self.identifier = identifier
        self.question = question
        self.entries = []
        self.notes = []
        self.directory = os.path.join(EVIDENCE, identifier)
        os.makedirs(self.directory, exist_ok=True)
        self.started = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    def run(self, label, argv, env=None, cwd=None, timeout=120):
        try:
            completed = subprocess.run(
                argv,
                capture_output=True,
                text=True,
                env=env if env is not None else None,
                cwd=cwd,
                timeout=timeout,
            )
            code, out, err = completed.returncode, completed.stdout, completed.stderr
        except subprocess.TimeoutExpired as expired:
            code = -1
            out = (expired.stdout or b"").decode("utf-8", "replace") if isinstance(
                expired.stdout, bytes) else (expired.stdout or "")
            err = ((expired.stderr or b"").decode("utf-8", "replace") if isinstance(
                expired.stderr, bytes) else (expired.stderr or "")) + \
                "\n[harness] killed after %d s\n" % timeout
        entry = {
            "label": label,
            "argv": argv,
            "cwd": cwd,
            "exit": code,
            "stdout": out,
            "stderr": err,
        }
        self.entries.append(entry)
        stem = os.path.join(self.directory, "%02d-%s" % (len(self.entries), slug(label)))
        with open(stem + ".cmd", "w") as handle:
            if cwd:
                handle.write("cd %s && " % shlex.quote(cwd))
            handle.write(" ".join(shlex.quote(part) for part in argv) + "\n")
        with open(stem + ".stdout", "w") as handle:
            handle.write(out)
        with open(stem + ".stderr", "w") as handle:
            handle.write(err)
        with open(stem + ".exit", "w") as handle:
            handle.write("%d\n" % code)
        return entry

    def fitsverify(self, label, path, extra=("-l",)):
        return self.run(label, [FITSVERIFY, *extra, path], env=CFITSIO_ENV)

    def funpack(self, label, path, out_path, extra=None):
        argv = [FUNPACK, *(extra if extra is not None else ("-C", "-O", out_path)), path]
        return self.run(label, argv, env=CFITSIO_ENV)

    def fpack(self, label, path, out_path, extra=None):
        argv = [FPACK, *(extra if extra is not None else ("-O", out_path)), path]
        return self.run(label, argv, env=CFITSIO_ENV)

    def note(self, text, **fields):
        self.notes.append(dict(text=text, **fields))

    def save(self):
        payload = {
            "experiment": self.identifier,
            "question": self.question,
            "started": self.started,
            "notes": self.notes,
            "runs": self.entries,
        }
        path = os.path.join(EVIDENCE, self.identifier + ".json")
        with open(path, "w") as handle:
            json.dump(payload, handle, indent=2)
            handle.write("\n")
        print("%s: %d runs -> %s" % (self.identifier, len(self.entries), path))
        return path


def cards_of(header_bytes, width=80):
    """Every non-blank 80-column card of a header block, END excluded."""
    out = []
    for offset in range(0, len(header_bytes), width):
        card = header_bytes[offset:offset + width]
        if card.strip() == b"":
            break
        if card[:8].rstrip() == b"END":
            break
        out.append(card)
    return out


def header_of(path):
    """The first header block of a FITS file, as bytes, padded to 2880.

    The padding matters: `data_of`/`array_bytes` index from the end of the block,
    and the block, not the END card, is what the format aligns to.
    """
    data = open(path, "rb").read()
    offset = 0
    while True:
        for within in range(0, 2880, 80):
            if data[offset + within:offset + within + 8].rstrip() == b"END":
                end = offset + 2880
                return data[:end]
        offset += 2880
        if offset >= len(data):
            raise ValueError("%s has no END card" % path)


def headers_of(path):
    """Every header block in the file, in order (2880-padded, END excluded from the tail)."""
    data = open(path, "rb").read()
    blocks = []
    offset = 0
    while offset < len(data):
        start = offset
        while True:
            for within in range(0, 2880, 80):
                if data[offset + within:offset + within + 8].rstrip() == b"END":
                    offset += 2880
                    blocks.append(data[start:offset])
                    break
            else:
                offset += 2880
                continue
            break
        # skip the data unit: read BITPIX/NAXIS to know its length
        text = blocks[-1].decode("ascii", "replace")
        try:
            bitpix = int(text.split("BITPIX  =")[1].split()[0])
            naxis = int(text.split("NAXIS   =")[1].split()[0])
        except IndexError:
            break
        count = 1
        for axis in range(1, naxis + 1):
            name = "NAXIS%d" % axis
            index = text.index(name + "  =")
            count *= int(text[index:index + 80].split("=")[1].split()[0])
        if naxis == 0:
            count = 0
        pcount = 0
        if "PCOUNT  =" in text:
            pcount = int(text.split("PCOUNT  =")[1].split()[0])
        gcount = 1
        if "GCOUNT  =" in text:
            gcount = int(text.split("GCOUNT  =")[1].split()[0])
        length = abs(bitpix) // 8 * (count + pcount) * gcount
        offset += (length + 2879) // 2880 * 2880
    return blocks


def data_of(path):
    """The image data unit of the first HDU (after its header, before padding)."""
    header = header_of(path)
    start = len(header)
    raw = open(path, "rb").read()
    return raw[start:]


def array_bytes(path):
    """The pixel array of the first image HDU, with the padding removed."""
    header = header_of(path)
    raw = open(path, "rb").read()
    start = len(header)
    bitpix = int(header.decode("ascii").split("BITPIX  =")[1].split()[0])
    naxis = int(header.decode("ascii").split("NAXIS   =")[1].split()[0])
    count = 1
    text = header.decode("ascii")
    for axis in range(1, naxis + 1):
        name = "NAXIS%d" % axis
        index = text.index(name + "  =")
        count *= int(text[index:index + 80].split("=")[1].split()[0])
    if naxis == 0:
        return b""
    length = abs(bitpix) // 8 * count
    return raw[start:start + length]


def card_diff(before, after):
    """Keyed diff of two headers at the 80-column level (P3 style).

    Returns a list of dicts with kind in {lost, invented, changed, reordered}.
    """
    left = cards_of(before)
    right = cards_of(after)

    def by_keyword(cards):
        seen = {}
        for index, card in enumerate(cards):
            seen.setdefault(card[:8].decode("ascii").rstrip(), []).append((index, card))
        return seen

    one = by_keyword(left)
    two = by_keyword(right)
    diffs = []
    for keyword in sorted(set(one) | set(two)):
        a = [card for _, card in one.get(keyword, [])]
        b = [card for _, card in two.get(keyword, [])]
        if a == b:
            continue
        if len(a) == 1 and len(b) == 1:
            diffs.append({"kind": "changed", "keyword": keyword,
                          "original": a[0].decode("ascii"), "rebuilt": b[0].decode("ascii")})
        elif not a:
            for card in b:
                diffs.append({"kind": "invented", "keyword": keyword,
                              "original": None, "rebuilt": card.decode("ascii")})
        elif not b:
            for card in a:
                diffs.append({"kind": "lost", "keyword": keyword,
                              "original": card.decode("ascii"), "rebuilt": None})
        else:
            diffs.append({"kind": "reordered", "keyword": keyword,
                          "original": [c.decode("ascii") for c in a],
                          "rebuilt": [c.decode("ascii") for c in b]})
    return diffs
