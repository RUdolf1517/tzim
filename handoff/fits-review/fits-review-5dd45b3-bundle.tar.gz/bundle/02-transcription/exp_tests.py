#!/usr/bin/env python3
"""E12: the test inventory behind F-07 and F-08.

No subprocess of CFITSIO here: this records what the repository's own tests do
and do not exercise, with the grep output and exit code of every search.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from harness import Experiment  # noqa: E402

REPO = "/home/user/tzim"
experiment = Experiment("E12-tests",
                        "F-07/F-08: is there any test that makes verify() fail, and which "
                        "cards does verify() compare?")

SEARCHES = [
    ("unit-test-names", ["grep", "-n", "-E", r"^    fn [a-z_0-9]+\(\)", "src/formats/fits.rs"]),
    ("expect_err", ["grep", "-n", "expect_err", "src/formats/fits.rs"]),
    ("verify-calls", ["grep", "-n", "verify(", "src/formats/fits.rs"]),
    ("check-tiled", ["sed", "-n", "860,940p", "src/formats/fits.rs"]),
    ("structural", ["sed", "-n", "452,470p", "src/formats/fits.rs"]),
    ("verification-rs-fits", ["grep", "-n", "-i", "fits", "tests/verification.rs"]),
    ("integration-rs-fits", ["grep", "-n", "fn fits", "tests/integration.rs"]),
    ("oracle-equal-nan", ["grep", "-n", "equal_nan", ".github/scripts/fits-oracle.py"]),
    ("oracle-int-compare", ["grep", "-n", "tobytes\\|array_equal", ".github/scripts/fits-oracle.py"]),
    ("oracle-except", ["grep", "-n", "except Exception", ".github/scripts/fits-oracle.py"]),
    ("workflow-oracle", ["grep", "-n", "fits-oracle", ".github/workflows/ci.yml"]),
    ("guarantees-2-6", ["sed", "-n", "82,100p", "docs/guarantees.md"]),
    ("guarantees-4-12", ["sed", "-n", "1005,1145p", "docs/guarantees.md"]),
    ("audit-8-3", ["sed", "-n", "300,315p", "docs/fits-audit.md"]),
    ("audit-table", ["sed", "-n", "148,160p", "docs/fits-audit.md"]),
]

for label, argv in SEARCHES:
    experiment.run(label, argv, env=dict(os.environ, LC_ALL="C"), cwd=REPO)

experiment.save()
