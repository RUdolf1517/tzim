#!/usr/bin/env python3
"""E00 (environment) and E01 (tool identity and provenance)."""
import hashlib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Experiment, CFITSIO_SRC, CFITSIO_ENV  # noqa: E402

REPO = "/home/user/tzim"
BUNDLE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(BUNDLE, "05-tools")
os.makedirs(TOOLS, exist_ok=True)

# --- E00: what this sandbox is -------------------------------------------
env = Experiment("E00-environment",
                 "What was available; what was not. No Rust toolchain means tzim was never run.")
env.run("uname", ["uname", "-a"])
env.run("gcc-version", ["gcc", "--version"])
env.run("python-version", [sys.executable, "--version"])
env.run("numpy-astropy", [sys.executable, "-c",
                          "import numpy, astropy; print('numpy', numpy.__version__); "
                          "print('astropy', astropy.__version__)"])
env.run("cargo-absent", ["bash", "-lc", "command -v cargo || echo 'cargo: not found'"])
env.run("rustc-absent", ["bash", "-lc", "command -v rustc || echo 'rustc: not found'"])
env.run("tzim-head", ["git", "-C", REPO, "rev-parse", "HEAD"])
env.run("tzim-status", ["git", "-C", REPO, "status", "--porcelain=v1"])
env.run("tzim-version-in-cargo", ["bash", "-lc",
                                  "grep -n '^version' %s/Cargo.toml" % REPO])
env.save()

# --- E01: the tools, and exactly where they came from ---------------------
tools = Experiment("E01-tools",
                   "Which CFITSIO, built from which commit, from which source; "
                   "which fitsverify binary produced the verdicts.")
tools.run("cfitsio-remote", ["git", "-C", CFITSIO_SRC, "remote", "-v"])
tools.run("cfitsio-head", ["git", "-C", CFITSIO_SRC, "rev-parse", "HEAD"])
tools.run("cfitsio-log", ["git", "-C", CFITSIO_SRC, "log", "-1",
                          "--format=%H%n%ci%n%s"])
tools.run("cfitsio-describe", ["git", "-C", CFITSIO_SRC, "describe", "--always", "--tags"])
for name in ("fitsverify", "fpack", "funpack"):
    tools.run("sha256-" + name, ["sha256sum", os.path.join(CFITSIO_SRC, name)])
tools.run("fitsverify-usage", [os.path.join(CFITSIO_SRC, "fitsverify"), "-h"],
          env=CFITSIO_ENV)
tools.run("funpack-version", [os.path.join(CFITSIO_SRC, "funpack"), "-V"],
          env=CFITSIO_ENV)
tools.run("funpack-help", [os.path.join(CFITSIO_SRC, "funpack"), "-H"],
          env=CFITSIO_ENV)
tools.run("fpack-usage", [os.path.join(CFITSIO_SRC, "fpack")], env=CFITSIO_ENV)
tools.save()

print("records written to", TOOLS)
