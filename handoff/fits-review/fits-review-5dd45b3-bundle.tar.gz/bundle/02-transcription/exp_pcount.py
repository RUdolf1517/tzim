#!/usr/bin/env python3
"""E11: F-04 — RETRACTED. Does the reference writer also emit ZPCOUNT/ZGCOUNT
for a compressed *primary* array?

If fpack does the same, the finding is not a defect of tzim and is retracted in
the report. The evidence is kept so the retraction can be checked.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
FIXTURES = os.path.join(BUNDLE, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
EVIDENCE = os.path.join(BUNDLE, "04-evidence")
sys.path.insert(0, HERE)
import model  # noqa: E402
import reader_model  # noqa: E402
from harness import Experiment, array_bytes, cards_of, header_of, headers_of  # noqa: E402

os.makedirs(DERIVED, exist_ok=True)
NAME = "pcount_primary"
original = os.path.join(FIXTURES, NAME + ".fits")

experiment = Experiment("E11-pcount",
                        "F-04 (RETRACTED): is ZPCOUNT/ZGCOUNT on a compressed primary "
                        "a tzim-specific fault, or reference behaviour?")

experiment.note("transcribed-decision", **reader_model.outcome(original))

header = header_of(original)
cards = [header[offset:offset + 80] for offset in range(0, len(header), 80)]
cards = [card for card in cards if card[:8].rstrip() != b"END" and card.strip()]
text = header.decode("ascii")
bitpix = int(text.split("BITPIX  =")[1].split()[0])
naxis = int(text.split("NAXIS   =")[1].split()[0])
axes = [int(text[text.index("NAXIS%d  =" % i):][:80].split("=")[1].split()[0])
        for i in range(1, naxis + 1)]
hdu = model.Hdu(cards, array_bytes(original), "Primary", bitpix, axes)
out = bytearray()
model.empty_primary(out)
model.write_tiled(hdu, out)
candidate = os.path.join(DERIVED, NAME + ".tzim-candidate.fits")
with open(candidate, "wb") as handle:
    handle.write(out)

tzim_cards = [card.decode("ascii").rstrip() for card in cards_of(headers_of(candidate)[1])]
experiment.note("tzim-table-cards", cards=tzim_cards)

packed = os.path.join(DERIVED, NAME + ".fpack.fits")
experiment.fpack("fpack", original, packed)
fpack_cards = [card.decode("ascii").rstrip() for card in cards_of(headers_of(packed)[1])]
experiment.note("fpack-table-cards", cards=fpack_cards)

experiment.fitsverify("fitsverify-tzim", candidate)
experiment.fitsverify("fitsverify-fpack", packed)

rebuilt_tzim = os.path.join(DERIVED, NAME + ".reconstructed.fits")
rebuilt_fpack = os.path.join(DERIVED, NAME + ".fpack.funpack.fits")
experiment.funpack("funpack-tzim", candidate, rebuilt_tzim)
experiment.funpack("funpack-fpack", packed, rebuilt_fpack)

for tag, path in (("tzim", rebuilt_tzim), ("fpack", rebuilt_fpack)):
    if os.path.exists(path):
        experiment.note("reconstructed-%s" % tag,
                        cards=[c.decode("ascii").rstrip() for c in cards_of(header_of(path))])

experiment.note("has-zpcount", tzim="ZPCOUNT" in " ".join(tzim_cards),
                fpack="ZPCOUNT" in " ".join(fpack_cards))
experiment.save()

print("tzim  cards:", [c for c in tzim_cards if c.startswith(("ZPCOUNT", "ZGCOUNT", "PCOUNT", "GCOUNT"))])
print("fpack cards:", [c for c in fpack_cards if c.startswith(("ZPCOUNT", "ZGCOUNT", "PCOUNT", "GCOUNT"))])
