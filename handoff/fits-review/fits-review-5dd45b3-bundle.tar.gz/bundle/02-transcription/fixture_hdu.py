#!/usr/bin/env python3
"""Shared by E05 and E14: the Hdu the writer would see, and a forced candidate.

`hdu_from_file` reads a fixture back into the transcription's `Hdu` type;
`forced_candidate` runs `empty_primary()` + `write_tiled()` and bypasses only the
size gate, so a format can be judged even where tzim would decline for lack of
gain. Both were defined inside exp_candidates.py and are moved here so that
importing them does not re-run E05.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import model  # noqa: E402
from harness import array_bytes, header_of  # noqa: E402


def hdu_from_file(path):
    """Rebuild the Hdu object the writer would see: cards + data + geometry."""
    header = header_of(path)
    cards = [header[offset:offset + 80] for offset in range(0, len(header), 80)]
    cards = [card for card in cards if card[:8].rstrip() != b"END" and card.strip()]
    text = header.decode("ascii")
    bitpix = int(text.split("BITPIX  =")[1].split()[0])
    naxis = int(text.split("NAXIS   =")[1].split()[0])
    axes = []
    for axis in range(1, naxis + 1):
        name = "NAXIS%d" % axis
        index = text.index(name + "  =")
        axes.append(int(text[index:index + 80].split("=")[1].split()[0]))
    data = array_bytes(path)
    kind = "Primary" if "SIMPLE" in {c[:8].decode().rstrip() for c in cards} else "ImageExt"
    return model.Hdu(cards, data, kind, bitpix, axes)


def forced_candidate(hdu):
    """empty_primary() + write_tiled(), without the `out.len() >= data.len()` gate."""
    out = bytearray()
    model.empty_primary(out)
    model.write_tiled(hdu, out)
    return bytes(out)
