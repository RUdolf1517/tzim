#!/usr/bin/env bash
# Build fitsverify / fpack / funpack from the exact CFITSIO commit the review used.
#
# Commit: 113781d8aa442cf8d3c27295d9084674b8b039f2  (heasarc/cfitsio, branch develop)
#         — the same commit PR #73 pins as CFITSIO_COMMIT.
#
# The build lives in /tmp because it is a tool artifact, not a review artifact.
# Everything needed to reproduce it is here; the resulting binary hashes are in
# 05-tools/*.json and in E01-tools/.
set -euo pipefail

PIN=113781d8aa442cf8d3c27295d9084674b8b039f2
SRC=/tmp/cfitsio-src
TOOLS="$(cd "$(dirname "$0")" && pwd)"

rm -rf "$SRC"
git clone --quiet https://github.com/heasarc/cfitsio.git "$SRC"
git -C "$SRC" fetch --quiet --depth 1 origin "$PIN"
git -C "$SRC" checkout --quiet FETCH_HEAD

head_sha=$(git -C "$SRC" rev-parse HEAD)
if [ "$head_sha" != "$PIN" ]; then
  echo "FATAL: checked out $head_sha, expected $PIN" >&2
  exit 1
fi

# The sandbox has zlib's runtime library but not its headers; the copy shipped
# with node provides zlib.h 1.3.1, and libz.so.1 is ABI-compatible for the calls
# CFITSIO makes. Recorded here so the reader knows this is not a stock build.
mkdir -p /tmp/zlib
ln -sf /usr/lib/x86_64-linux-gnu/libz.so.1 /tmp/zlib/libz.so

cd "$SRC"
./configure --prefix=/tmp/cfitsio-inst \
    CC=gcc \
    CPPFLAGS="-I/usr/local/include/node" \
    LDFLAGS="-L/tmp/zlib -Wl,-rpath,/usr/lib/x86_64-linux-gnu" \
    > "$TOOLS/configure.log" 2>&1
make -j"$(nproc)" > "$TOOLS/make.log" 2>&1

git rev-parse HEAD > "$TOOLS/cfitsio-rev.txt"
git log -1 --format='%H%n%ci%n%s' >> "$TOOLS/cfitsio-rev.txt"
sha256sum "$SRC/fitsverify" "$SRC/fpack" "$SRC/funpack" > "$TOOLS/binary-sha256.txt"
"$SRC/funpack" -V >> "$TOOLS/cfitsio-rev.txt" 2>&1 || true

echo "built at $SRC, commit $head_sha"
cat "$TOOLS/binary-sha256.txt"
