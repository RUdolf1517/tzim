/* Round trip eight float32 bit patterns through the reviewed libcfitsio.
 *
 *   gcc -I/tmp/cfitsio-src -o /tmp/cfitsio-roundtrip cfitsio-roundtrip.c \
 *       -L/tmp/cfitsio-src/.libs -lcfitsio -Wl,-rpath,/tmp/cfitsio-src/.libs
 *
 * The values are chosen so that any canonicalisation shows: a denormal, the
 * largest negative denormal, -0.0, a quiet NaN with payload 1, +inf, -inf, 1.0
 * and FLT_MAX. The image is written as a tile-compressed GZIP_2 HDU through the
 * public API and read back through the public API; `in` and `out` must match.
 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "fitsio.h"

static void show(const char *tag, const uint32_t *bits, int n)
{
    printf("%-6s", tag);
    for (int i = 0; i < n; i++) printf(" %08X", bits[i]);
    printf("\n");
}

int main(void)
{
    fitsfile *f;
    int status = 0;
    long naxes[1] = {8};
    long tile[1] = {8};
    uint32_t in[8] = {0x00000001, 0x807FFFFF, 0x80000000, 0x7FC00001,
                      0x7F800000, 0xFF800000, 0x3F800000, 0x7F7FFFFF};
    float buffer[8];
    float back[8];

    memcpy(buffer, in, sizeof in);
    remove("/tmp/cfitsio-roundtrip.fits");

    fits_create_file(&f, "!/tmp/cfitsio-roundtrip.fits", &status);
    /* The compression options have to be set *before* the image is created;
     * that is what routes the create through imcomp_init_table() and produces a
     * ZIMAGE BINTABLE instead of a plain primary array. */
    fits_set_compression_type(f, GZIP_2, &status);
    fits_set_tile_dim(f, 1, tile, &status);
    fits_create_img(f, FLOAT_IMG, 1, naxes, &status);   /* BITPIX = -32 */
    fits_write_img(f, TFLOAT, 1, 8, buffer, &status);
    printf("write status = %d\n", status);
    fits_close_file(f, &status);
    printf("close status = %d\n", status);

    status = 0;
    memset(back, 0, sizeof back);
    fits_open_file(&f, "/tmp/cfitsio-roundtrip.fits", READONLY, &status);
    /* the compressed image is the BINTABLE after the empty primary */
    fits_movabs_hdu(f, 2, NULL, &status);
    fits_read_img(f, TFLOAT, 1, 8, NULL, back, NULL, &status);
    printf("read status = %d\n", status);
    fits_close_file(f, &status);

    show("in", in, 8);
    show("out", (uint32_t *)back, 8);
    printf("identical = %s\n", memcmp(in, back, sizeof in) ? "no" : "yes");
    return memcmp(in, back, sizeof in) ? 1 : 0;
}
