#!/usr/bin/env python3
"""Minimal FITS inputs for the review of 5dd45b3, built from the transcription.

Every file is deterministic: same bytes on every run (no timestamps, no random
data). The script prints the sha256 of each file so the bundle can be checked.

Inputs and why each exists:

  int16_primary.fits     primary 80x128 int16 with ffphps-style cards and
                         comments -> the F-03 case (EXTEND + card comments) and
                         the general gzip path (§7, §9, mutations)
  int8_primary.fits      primary 100x100 int8, GZIP_1, no EXTEND
  float32_specials.fits  primary 48x64 float32 with NaN payloads, -0.0, +0.0,
                         +-inf -> round trip at the *bit* level (review area 4)
  bzero_float.fits       primary 10x12 int16 with BSCALE = 1, BZERO = 32768.0
                         (the uint16 convention) -> F-05
  pcount_primary.fits    primary 10x12 int16 with PCOUNT = 0, GCOUNT = 1
                         -> F-04, which is RETRACTED: fpack does the same
  random_groups.fits     legal random-groups primary (GROUPS = T, NAXIS1 = 0,
                         NAXIS2 = 1024, PCOUNT = 3, GCOUNT = 4) -> F-01
  simple_f_empty.fits    SIMPLE = F, NAXIS = 0 -> F-02 (legal boundary case)
  simple_f_data.fits     SIMPLE = F, NAXIS = 2, BITPIX = 8, 32x32 -> F-02
  extend_f_primary.fits  primary with EXTEND = F and a comment -> F-03, second
                         case: the "no extensions" claim is lost
"""
import hashlib
import json
import os
import struct
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "02-transcription"))
import model  # noqa: E402

OUT = HERE


def save(name, blob):
    path = os.path.join(OUT, name)
    with open(path, "wb") as handle:
        handle.write(blob)
    return {
        "file": name,
        "bytes": len(blob),
        "sha256": hashlib.sha256(blob).hexdigest(),
    }


def pattern_int(size, dtype):
    return (np.arange(size, dtype=np.int64) % 251).astype(dtype)


def primary_cards(bitpix, axes, extend=True, extend_comment="FITS dataset may contain extensions",
                  simple_comment="conforms to FITS standard",
                  bitpix_comment="number of bits per data pixel",
                  naxis_comment="number of data axes",
                  extra=(), simple=True):
    cards = [
        model.boolean_card("SIMPLE", True, simple_comment) if simple
        else model.assemble("%-8s= %20s" % ("SIMPLE", "F"), simple_comment),
        model.numeric_card("BITPIX", bitpix, bitpix_comment),
        model.numeric_card("NAXIS", len(axes), naxis_comment),
    ]
    for index, axis in enumerate(axes):
        cards.append(model.numeric_card("NAXIS%d" % (index + 1), axis, ""))
    if extend is not None:
        cards.append(model.boolean_card("EXTEND", extend, extend_comment))
    for keyword, raw in extra:
        cards.append(model.assemble("%-8s= %s" % (keyword, raw), ""))
    return cards


manifest = []

# --- int16 primary: the F-03 / general case --------------------------------
# 256x256 of a smooth ramp: large enough that the tiled form is strictly
# smaller, so the candidate is one tzim would actually write, not a forced one.
shape = (256, 256)
yy, xx = np.mgrid[0:256, 0:256]
data = ((xx * 7 + yy * 3) % 1000).astype(">i2").tobytes()
cards = primary_cards(16, list(shape), extend=True)
manifest.append(save("int16_primary.fits", model.header_bytes(cards) + model.data_block(data)))

# --- int8 primary, no EXTEND ---------------------------------------------
data8 = pattern_int(100 * 100, ">u1").tobytes()
cards8 = primary_cards(8, [100, 100], extend=None)
manifest.append(save("int8_primary.fits", model.header_bytes(cards8) + model.data_block(data8)))

# --- float32 with special values ------------------------------------------
special_bits = [
    0x7F800000,  # +inf
    0xFF800000,  # -inf
    0x7FC00001,  # quiet NaN, payload 1
    0x7FC00002,  # quiet NaN, payload 2
    0x7FA00001,  # signalling NaN, payload 1
    0x00000000,  # +0.0
    0x80000000,  # -0.0
    0x3F800000,  # 1.0
    0xBF800000,  # -1.0
    0x00000001,  # smallest denormal
    0x807FFFFF,  # negative denormal (max magnitude)
    0x7F7FFFFF,  # FLT_MAX
]
count = 64 * 64
yy, xx = np.mgrid[0:64, 0:64]
# a smooth float field (compresses after the GZIP_2 shuffle) with the twelve
# special bit patterns of the list above in its first samples
bits = (1000.0 + xx * 0.5 + yy * 0.25).astype(">f4").astype(">u4").ravel().astype(np.uint32)
for index, value in enumerate(special_bits):
    bits[index] = np.uint32(value)
f32 = bits.astype(">u4").view(">f4").reshape(64, 64)
cards_f = primary_cards(-32, [64, 64], extend=True)
manifest.append(save("float32_specials.fits",
                     model.header_bytes(cards_f) + model.data_block(f32.tobytes())))

# --- BSCALE/BZERO written as floats (F-05) --------------------------------
data_s = pattern_int(10 * 12, ">i2").tobytes()
cards_s = primary_cards(16, [10, 12], extend=True,
                        extra=[("BSCALE", "1"), ("BZERO", "32768.0")])
manifest.append(save("bzero_float.fits",
                     model.header_bytes(cards_s) + model.data_block(data_s)))

# --- a genuinely non-identity scaling, written as floats (F-05) -----------
# BSCALE = 2.5 / BZERO = -100.0 is not the identity, so the contract says the HDU
# must be refused; the card is a float, so `parse::<i64>` fails and it is tiled.
cards_s2 = primary_cards(16, [10, 12], extend=True,
                         extra=[("BSCALE", "2.5"), ("BZERO", "-100.0")])
manifest.append(save("bscale_two_five.fits",
                     model.header_bytes(cards_s2) + model.data_block(data_s)))

# --- primary with PCOUNT/GCOUNT (F-04, retracted) -------------------------
cards_p = primary_cards(16, [10, 12], extend=True,
                        extra=[("PCOUNT", "0"), ("GCOUNT", "1")])
manifest.append(save("pcount_primary.fits",
                     model.header_bytes(cards_p) + model.data_block(data_s)))

# --- legal random groups (F-01) -------------------------------------------
# FITS 4.0 §6.2: NAXIS1 = 0 and GROUPS = T mark random groups; the data length
# is |BITPIX|/8 * GCOUNT * (PCOUNT + NAXIS2 * ... * NAXISm), NAXIS1 excluded.
groups_cards = [
    model.boolean_card("SIMPLE", True, "conforms to FITS standard"),
    model.numeric_card("BITPIX", -32, "number of bits per data pixel"),
    model.numeric_card("NAXIS", 2, "number of data axes"),
    model.numeric_card("NAXIS1", 0, ""),
    model.numeric_card("NAXIS2", 1024, ""),
    model.boolean_card("GROUPS", True, "random groups records are present"),
    model.numeric_card("PCOUNT", 3, "number of parameters per group"),
    model.numeric_card("GCOUNT", 4, "number of groups"),
    model.boolean_card("EXTEND", True, "FITS dataset may contain extensions"),
]
groups_data_len = 4 * (3 + 1024) * 4
groups_data = (np.arange(groups_data_len // 4, dtype=np.int64) % 977).astype(">f4").tobytes()
manifest.append(save("random_groups.fits",
                     model.header_bytes(groups_cards) + model.data_block(groups_data)))

# --- SIMPLE = F, empty ----------------------------------------------------
simple_f_empty = [
    model.assemble("%-8s= %20s" % ("SIMPLE", "F"), "does not conform to FITS standard"),
    model.numeric_card("BITPIX", 8, "number of bits per data pixel"),
    model.numeric_card("NAXIS", 0, "number of data axes"),
]
manifest.append(save("simple_f_empty.fits", model.header_bytes(simple_f_empty)))

# --- SIMPLE = F, with data ------------------------------------------------
# 256x256 of a smooth 8-bit image: large enough that a tiled candidate would be
# strictly smaller, so the *decision* (not the size gate) is what is being shown.
yy, xx = np.mgrid[0:256, 0:256]
simple_f_data = [
    model.assemble("%-8s= %20s" % ("SIMPLE", "F"), "does not conform to FITS standard"),
    model.numeric_card("BITPIX", 8, "number of bits per data pixel"),
    model.numeric_card("NAXIS", 2, "number of data axes"),
    model.numeric_card("NAXIS1", 256, ""),
    model.numeric_card("NAXIS2", 256, ""),
]
manifest.append(save("simple_f_data.fits",
                     model.header_bytes(simple_f_data)
                     + model.data_block((((xx + yy) // 4) % 256).astype(">u1").tobytes())))

# --- EXTEND = F ----------------------------------------------------------
cards_x = primary_cards(16, list(shape), extend=False, extend_comment="no extensions here")
manifest.append(save("extend_f_primary.fits",
                     model.header_bytes(cards_x) + model.data_block(data)))

with open(os.path.join(OUT, "fixtures.json"), "w") as handle:
    json.dump(manifest, handle, indent=2)
    handle.write("\n")
for entry in manifest:
    print("%-24s %8d bytes  sha256 %s" % (entry["file"], entry["bytes"], entry["sha256"]))
