#!/usr/bin/env bash
# The exact sequence that produced 04-evidence/.
#
# Prerequisites:
#   * a Python with numpy and astropy:  python3 -m venv /tmp/venv
#                                      /tmp/venv/bin/pip install --retries 5 --timeout 60 numpy astropy
#   * CFITSIO built at the pinned SHA:  05-tools/build-tools.sh
#   * the repository at 5dd45b38412ffb762a1fc380bd291351c9e6601e on disk at /home/user/tzim
#
# Every script writes its own stdout/stderr/exit under 04-evidence/scripts/ and
# its data under 04-evidence/<experiment>/.
set -uo pipefail

BUNDLE="$(cd "$(dirname "$0")/.." && pwd)"
PY=/tmp/venv/bin/python
LOGS="$BUNDLE/04-evidence/scripts"
# Idempotent: every record and every derived file is regenerated from scratch, so
# that a second run cannot be green because a stale file was left over.
rm -rf "$BUNDLE/04-evidence" "$BUNDLE/01-fixtures/derived"
mkdir -p "$LOGS"

run() {
    local name="$1"; shift
    "$@" > "$LOGS/$name.stdout" 2> "$LOGS/$name.stderr"
    echo "$?" > "$LOGS/$name.exit"
    printf '%-24s exit=%s\n' "$name" "$(cat "$LOGS/$name.exit")"
}

# The tools this run depends on.
if [ ! -x /tmp/cfitsio-src/fitsverify ]; then
    echo "CFITSIO is not built; run 05-tools/build-tools.sh first" >&2
    exit 1
fi

run E00-E01-tools        "$PY" "$BUNDLE/02-transcription/exp_tools.py"
run E02-E03-fixtures     "$PY" "$BUNDLE/02-transcription/exp_fixtures.py"
run E04-decisions        "$PY" "$BUNDLE/02-transcription/exp_decisions.py"
run E05-candidates       "$PY" "$BUNDLE/02-transcription/exp_candidates.py"
run E06-reference        "$PY" "$BUNDLE/02-transcription/exp_reference.py"
run E07-headerdiff       "$PY" "$BUNDLE/02-transcription/exp_headerdiff.py"
run E08-mutations        "$PY" "$BUNDLE/02-transcription/exp_mutations.py"
run E09-gate             "$PY" "$BUNDLE/02-transcription/exp_gate.py"
run E10-scaling          "$PY" "$BUNDLE/02-transcription/exp_scaling.py"
run E11-pcount           "$PY" "$BUNDLE/02-transcription/exp_pcount.py"
run E12-tests            "$PY" "$BUNDLE/02-transcription/exp_tests.py"
run E13-znmae            "$PY" "$BUNDLE/02-transcription/exp_znmae.py"
run E14-oracle-rule      "$PY" "$BUNDLE/02-transcription/exp_oracle_rule.py"
run E15-library-vs-fpack "$PY" "$BUNDLE/02-transcription/exp_library.py"

run E99-analysis          "$PY" "$BUNDLE/03-commands/analyze.py"
"$PY" "$BUNDLE/03-commands/collect.py"
