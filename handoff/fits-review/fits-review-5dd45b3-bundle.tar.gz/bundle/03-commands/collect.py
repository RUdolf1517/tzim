#!/usr/bin/env python3
"""Build 04-evidence/INDEX.md and index.json from the per-run files.

Every row points at the .cmd/.stdout/.stderr/.exit quadruple it was built from,
so any claim in the report can be checked without re-running anything.
"""
import json
import os

BUNDLE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EVIDENCE = os.path.join(BUNDLE, "04-evidence")

rows = []
for name in sorted(os.listdir(EVIDENCE)):
    directory = os.path.join(EVIDENCE, name)
    if not os.path.isdir(directory) or name == "scripts":
        continue
    exits = sorted(f for f in os.listdir(directory) if f.endswith(".exit"))
    for exit_file in exits:
        stem = exit_file[:-5]
        exit_value = int(open(os.path.join(directory, exit_file)).read().strip())
        command = open(os.path.join(directory, stem + ".cmd")).read().strip()
        stdout_path = os.path.join(directory, stem + ".stdout")
        stderr_path = os.path.join(directory, stem + ".stderr")
        stdout = open(stdout_path).read() if os.path.exists(stdout_path) else ""
        first = next((line.strip() for line in stdout.splitlines() if line.strip()), "")
        rows.append({
            "experiment": name,
            "label": stem.split("-", 1)[1] if "-" in stem else stem,
            "command": command,
            "exit": exit_value,
            "summary": first[:160],
            "files": [os.path.relpath(path, BUNDLE) for path in
                      (os.path.join(directory, stem + ext)
                       for ext in (".cmd", ".stdout", ".stderr", ".exit"))],
        })

with open(os.path.join(EVIDENCE, "index.json"), "w") as handle:
    json.dump(rows, handle, indent=2)
    handle.write("\n")

lines = ["# Evidence index", "",
         "Every run below was executed in the sandbox; `exit` is the process exit status.",
         "`file` columns are relative to the bundle root. Nothing is truncated.", "",
         "| experiment | run | exit | first line of stdout | files |",
         "| --- | --- | --- | --- | --- |"]
for row in rows:
    files = "<br>".join(os.path.basename(path) for path in row["files"])
    summary = row["summary"].replace("|", "\\|")
    lines.append("| %s | %s | %d | %s | %s |" % (
        row["experiment"], row["label"].replace("|", "\\|"), row["exit"], summary, files))
lines.append("")
lines.append("%d runs in %d experiments." % (
    len(rows), len({row["experiment"] for row in rows})))
with open(os.path.join(EVIDENCE, "INDEX.md"), "w") as handle:
    handle.write("\n".join(lines) + "\n")

print("%d runs indexed -> %s" % (len(rows), os.path.join(EVIDENCE, "INDEX.md")))
