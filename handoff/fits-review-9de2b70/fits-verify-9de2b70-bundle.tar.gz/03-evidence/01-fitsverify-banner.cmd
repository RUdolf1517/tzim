fitsverify -l /home/user/fits-verify-9de2b70/01-fixtures/orig_int16.fits
