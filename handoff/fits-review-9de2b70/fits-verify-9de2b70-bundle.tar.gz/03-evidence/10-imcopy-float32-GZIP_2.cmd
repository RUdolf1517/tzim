cd /home/user/fits-verify-9de2b70/01-fixtures && imcopy orig_float32.fits 'derived/cand_float32.imcopy.fits.fz[compress GZIP_2]'
