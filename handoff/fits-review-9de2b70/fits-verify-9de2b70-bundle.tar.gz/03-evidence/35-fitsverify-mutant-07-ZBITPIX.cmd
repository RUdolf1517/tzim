fitsverify -l /home/user/fits-verify-9de2b70/01-fixtures/derived/mutant-07.fits.fz
