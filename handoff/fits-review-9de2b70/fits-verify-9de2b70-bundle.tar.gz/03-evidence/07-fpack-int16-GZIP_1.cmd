cd /home/user/fits-verify-9de2b70 && fpack -g -q 0 -C -O /home/user/fits-verify-9de2b70/01-fixtures/derived/cand_int16.fpack.fits.fz /home/user/fits-verify-9de2b70/01-fixtures/orig_int16.fits
