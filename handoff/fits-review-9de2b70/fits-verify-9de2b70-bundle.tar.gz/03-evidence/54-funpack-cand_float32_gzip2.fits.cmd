funpack -C -O /home/user/fits-verify-9de2b70/06-scratch/cand_float32_gzip2.apiunpacked.fits /home/user/fits-verify-9de2b70/01-fixtures/cand_float32_gzip2.fits
