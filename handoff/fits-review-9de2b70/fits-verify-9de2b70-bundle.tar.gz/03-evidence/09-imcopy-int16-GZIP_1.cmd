cd /home/user/fits-verify-9de2b70/01-fixtures && imcopy orig_int16.fits 'derived/cand_int16.imcopy.fits.fz[compress GZIP_1]'
