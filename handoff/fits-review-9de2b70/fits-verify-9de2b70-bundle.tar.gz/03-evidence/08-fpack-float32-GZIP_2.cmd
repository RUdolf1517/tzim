cd /home/user/fits-verify-9de2b70 && fpack -g2 -q 0 -C -O /home/user/fits-verify-9de2b70/01-fixtures/derived/cand_float32.fpack.fits.fz /home/user/fits-verify-9de2b70/01-fixtures/orig_float32.fits
