funpack -C -O /home/user/fits-verify-9de2b70/06-scratch/decoded-cand_float32_gzip1.imcopy.fits.fz /home/user/fits-verify-9de2b70/01-fixtures/derived/cand_float32_gzip1.imcopy.fits.fz
