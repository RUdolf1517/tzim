fitsverify -l /home/user/fits-verify-9de2b70/01-fixtures/derived/cand_float32_gzip1.imcopy.fits.fz
