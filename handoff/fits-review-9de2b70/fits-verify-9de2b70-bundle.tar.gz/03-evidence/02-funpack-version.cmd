funpack -V
