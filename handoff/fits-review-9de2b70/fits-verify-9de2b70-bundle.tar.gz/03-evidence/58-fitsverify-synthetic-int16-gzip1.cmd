fitsverify -l /home/user/fits-verify-9de2b70/01-fixtures/derived/synthetic-int16-gzip1.fits.fz
