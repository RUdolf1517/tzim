cd /home/user/fits-verify-9de2b70/01-fixtures && imcopy orig_float32_poszero.fits 'derived/cand_float32_poszero.fits.fz[compress GZIP_2]'
