/tmp/fits-review-make-candidates /home/user/fits-verify-9de2b70/01-fixtures
