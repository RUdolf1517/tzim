gcc -O1 -Wall -Wextra -o /tmp/fits-review-make-candidates /home/user/fits-verify-9de2b70/04-tools/make_candidates.c -I/tmp/tools/src -L/tmp/tools/src/.libs -lcfitsio -lm
