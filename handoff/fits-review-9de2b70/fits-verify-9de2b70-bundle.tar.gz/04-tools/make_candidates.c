/*
 * Fixtures for the FITS review, written by libcfitsio itself.
 *
 * The point of writing them through the C API rather than by hand is that the
 * compression here is the reference implementation's, not the tool under
 * review, and that every file can be read back and compared byte for byte.
 *
 *   orig_int16.fits            64x64 int16 primary image, plain
 *   cand_int16_gzip1.fits      that image compressed with GZIP_1
 *   orig_float32.fits          64x64 float32 primary image, 12 IEEE specials
 *   orig_float32_nan2.fits     identical header, one NaN payload changed
 *   orig_float32_poszero.fits  identical header, one -0.0 replaced by +0.0
 *   cand_float32_gzip2.fits    float32 image compressed with GZIP_2
 *   cand_float32_gzip1.fits    the same image, GZIP_1
 *   cand_float32_nan2.fits     that image compressed GZIP_2
 *   cand_float32_poszero.fits  that image compressed GZIP_2
 *
 * Every candidate is read back through the API and compared with the array that
 * was written; the program exits non-zero if any round trip differs.
 *
 * Build:  gcc -O1 -o make_candidates make_candidates.c \
 *             -I<cfitsio>/src -L<cfitsio>/src/.libs -lcfitsio -lm
 * Run:    ./make_candidates <output-directory>
 */
#include <fitsio.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define W 64
#define H 64
#define NPIX (W * H)

static int failures = 0;

static void fail(int status, const char *what)
{
    if (status) {
        fits_report_error(stderr, status);
        fprintf(stderr, "fatal: %s\n", what);
        exit(2);
    }
}

static void fill_int16(int16_t *image)
{
    for (int i = 0; i < NPIX; i++) {
        image[i] = (int16_t)(((i / 4) % 251) - 125);
    }
}

static float as_float(uint32_t bits)
{
    float value;
    memcpy(&value, &bits, sizeof value);
    return value;
}

/* The twelve specials that a lossless float path must preserve, then a smooth
 * pattern so that gzip has something to win on. */
static void fill_float(float *image, int variant)
{
    static const uint32_t specials[12] = {
        0x7f800000, /* +inf                      */
        0xff800000, /* -inf                      */
        0x7fc00001, /* quiet NaN, payload 1      */
        0x7fc00002, /* quiet NaN, payload 2      */
        0x7fa00001, /* signalling NaN            */
        0x00000000, /* +0.0                      */
        0x80000000, /* -0.0                      */
        0x00000001, /* smallest positive denormal*/
        0x807fffff, /* largest negative denormal */
        0x7f7fffff, /* largest finite float      */
        0x3f800000, /* 1.0                       */
        0xbf800000  /* -1.0                      */
    };
    for (int i = 0; i < 12; i++) {
        image[i] = as_float(specials[i]);
    }
    for (int i = 12; i < NPIX; i++) {
        image[i] = (float)(((i / 4) % 251) - 125);
    }
    if (variant == 1) {
        /* pixel 2 held qNaN payload 1; make it payload 2 */
        image[2] = as_float(0x7fc00002);
    }
    if (variant == 2) {
        /* pixel 6 held -0.0; make it +0.0 */
        image[6] = as_float(0x00000000);
    }
}

static void add_metadata(fitsfile *f, const char *unit, int *status)
{
    fits_write_key_str(f, "BUNIT", unit, "physical unit of the array", status);
    fits_write_key_str(f, "OBJECT", "M31", "object observed", status);
    fail(*status, "writing BUNIT/OBJECT");
}

/* A plain primary image. */
static void write_plain(const char *path, int bitpix, const void *image,
                        const char *unit)
{
    fitsfile *f = NULL;
    int status = 0;
    long naxes[2] = {W, H};
    int datatype = bitpix == 16 ? TSHORT : TFLOAT;
    size_t element = bitpix == 16 ? sizeof(int16_t) : sizeof(float);

    remove(path);
    fits_create_file(&f, path, &status);
    fits_create_img(f, bitpix, 2, naxes, &status);
    fail(status, "creating a plain primary image");
    add_metadata(f, unit, &status);
    fits_write_img(f, datatype, 1, NPIX, (void *)image, &status);
    fail(status, "writing the plain image");
    fits_close_file(f, &status);
    fail(status, "closing the plain image");
    (void)element;
}

/* A tile-compressed image: empty primary, then the compressed BINTABLE. */
static void write_compressed(const char *path, int bitpix, const void *image,
                             const char *unit, int codec)
{
    fitsfile *f = NULL;
    int status = 0;
    long naxes[2] = {W, H};
    long tiles[2] = {W, 1};
    int datatype = bitpix == 16 ? TSHORT : TFLOAT;

    remove(path);
    fits_create_file(&f, path, &status);
    /* The compression switches apply to the HDU that is created *next*: set
     * them before `fits_create_img`, or the image is written uncompressed.
     * Creating the image directly on the new file makes it a compressed
     * *primary*: CFITSIO still writes an empty primary in front of the table,
     * but marks it ZSIMPLE, so a reader gives back a primary image. */
    fits_set_compression_type(f, codec, &status);
    fits_set_tile_dim(f, 2, tiles, &status);
    if (bitpix < 0) {
        /* Quantisation off, explicitly: a reader may not assume it. */
        fits_set_quantize_level(f, 0.0f, &status);
    }
    fail(status, "configuring the compressed HDU");
    fits_create_img(f, bitpix, 2, naxes, &status);
    fail(status, "creating the image to compress");
    add_metadata(f, unit, &status);
    fits_write_img(f, datatype, 1, NPIX, (void *)image, &status);
    fail(status, "writing the compressed image");
    fits_close_file(f, &status);
    fail(status, "closing the compressed image");
}

/* Reads back the array an API reader sees and compares it with what was
 * written. Bitwise: this is the control that says the fixtures are exact. */
static void read_back(const char *path, int bitpix, const void *expected)
{
    fitsfile *f = NULL;
    int status = 0;
    int hdutype = 0;
    int datatype = bitpix == 16 ? TSHORT : TFLOAT;
    int anynul = 0;
    size_t element = bitpix == 16 ? sizeof(int16_t) : sizeof(float);
    unsigned char got[NPIX * sizeof(float)];

    fits_open_file(&f, path, READONLY, &status);
    fail(status, "opening for the round trip");
    fits_movabs_hdu(f, 2, &hdutype, &status); /* an empty primary comes first */
    fail(status, "moving to the compressed HDU");
    memset(got, 0, sizeof got);
    fits_read_img(f, datatype, 1, NPIX, NULL, got, &anynul, &status);
    fail(status, "reading the compressed image back");
    fits_close_file(f, &status);
    fail(status, "closing after the round trip");

    int same = memcmp(got, expected, (size_t)NPIX * element) == 0;
    printf("%-30s %6d bytes  round trip: bytes identical: %s\n",
           path, (int)((size_t)NPIX * element), same ? "yes" : "NO");
    if (!same) {
        failures++;
        for (int i = 0; i < NPIX; i++) {
            if (memcmp(got + (size_t)i * element,
                       (const unsigned char *)expected + (size_t)i * element,
                       element) != 0) {
                printf("   first differing sample: %d\n", i);
                break;
            }
        }
    }
}

static void size_of(const char *path)
{
    FILE *handle = fopen(path, "rb");
    if (!handle) {
        printf("%-30s missing\n", path);
        failures++;
        return;
    }
    fseek(handle, 0, SEEK_END);
    long bytes = ftell(handle);
    fclose(handle);
    printf("%-30s %6ld bytes\n", path, bytes);
}

int main(int argc, char **argv)
{
    static int16_t int16_image[NPIX];
    static float float_image[NPIX];
    static float float_nan2[NPIX];
    static float float_poszero[NPIX];
    char path[4096];

    if (argc != 2) {
        fprintf(stderr, "usage: %s <output-directory>\n", argv[0]);
        return 2;
    }
    const char *root = argv[1];
#define P(name) (snprintf(path, sizeof path, "%s/%s", root, name), path)

    fill_int16(int16_image);
    fill_float(float_image, 0);
    fill_float(float_nan2, 1);
    fill_float(float_poszero, 2);

    write_plain(P("orig_int16.fits"), 16, int16_image, "COUNTS");
    write_compressed(P("cand_int16_gzip1.fits"), 16, int16_image, "COUNTS", GZIP_1);

    write_plain(P("orig_float32.fits"), -32, float_image, "JY");
    write_plain(P("orig_float32_nan2.fits"), -32, float_nan2, "JY");
    write_plain(P("orig_float32_poszero.fits"), -32, float_poszero, "JY");

    write_compressed(P("cand_float32_gzip2.fits"), -32, float_image, "JY", GZIP_2);
    write_compressed(P("cand_float32_gzip1.fits"), -32, float_image, "JY", GZIP_1);
    write_compressed(P("cand_float32_nan2.fits"), -32, float_nan2, "JY", GZIP_2);
    write_compressed(P("cand_float32_poszero.fits"), -32, float_poszero, "JY", GZIP_2);

    printf("\n");
    size_of(P("orig_int16.fits"));
    size_of(P("cand_int16_gzip1.fits"));
    size_of(P("orig_float32.fits"));
    size_of(P("cand_float32_gzip2.fits"));
    size_of(P("cand_float32_gzip1.fits"));

    printf("\n");
    read_back(P("cand_int16_gzip1.fits"), 16, int16_image);
    read_back(P("cand_float32_gzip2.fits"), -32, float_image);
    read_back(P("cand_float32_gzip1.fits"), -32, float_image);
    read_back(P("cand_float32_nan2.fits"), -32, float_nan2);
    read_back(P("cand_float32_poszero.fits"), -32, float_poszero);

    printf("\nall round trips exact (%d failure(s))\n", failures);
    return failures == 0 ? 0 : 1;
}
