#!/usr/bin/env python3
"""Baseline at 9de2b7069a52: what can be executed here, and what cannot.

There is no Rust toolchain in this sandbox and no route to one
(static.rust-lang.org and crates.io are unreachable), so **the tzim binary of
9de2b70 was never built or run**. Everything that needs it is `not run`.

What *is* executed, with the real tools:

  * `fitsverify` 4.22 and `fpack`/`funpack` 1.7.0 built from the archive the
    project pins (`113781d8aa44…`, sha256 `d93c0de3…`) — the same archive and
    hash the workflow verifies;
  * the gate `.github/scripts/fits-heasarc.py` **from 9de2b70**, imported so
    that its own `check_candidate` judges every file, and also run as a CLI
    (`--self-check`);
  * the oracle `.github/scripts/fits-oracle.py` **from 9de2b70**, its own
    `check_rewritten`;
  * real candidates written by `fpack` and by `imcopy '[compress …]'` of the
    same build;
  * a second writing of the layout `write_tiled` describes, judged by the same
    gate (this is a layout transcription, not a run of the binary).

Nothing below is a transcription of the review text: every verdict comes from
running code that exists at the reviewed SHA, against files that were written
and read by the HEASARC tools.
"""
import hashlib
import importlib.util
import json
import os
import platform
import struct
import subprocess
import sys

import numpy as np

from harness import Recorder

SHA = "9de2b7069a522ab5ce05e8255a3ce4c530f6190f"
REPO = "/home/user/tzim"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIXTURES = os.path.join(ROOT, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
EVIDENCE = os.path.join(ROOT, "03-evidence")
EXTRACT = os.path.join(ROOT, "05-extracted-at-sha")
SCRATCH = os.path.join(ROOT, "06-scratch")
TOOLS = "/tmp/tools/src/.libs"

for directory in (DERIVED, EXTRACT, SCRATCH):
    os.makedirs(directory, exist_ok=True)

os.environ["PATH"] = TOOLS + ":" + os.environ["PATH"]
os.environ["LD_LIBRARY_PATH"] = TOOLS
ENV = dict(os.environ)

recorder = Recorder(EVIDENCE)


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def blob_sha256(path):
    """git's hash of the blob at the reviewed SHA, not of the working tree."""
    result = subprocess.run(["git", "-C", REPO, "show", "%s:%s" % (SHA, path)],
                            capture_output=True)
    if result.returncode != 0:
        return "absent: %s" % result.stderr.decode("utf-8", "replace").strip()
    return hashlib.sha256(result.stdout).hexdigest()


def gate_evidence():
    return gate.Evidence(os.path.join(EVIDENCE, "gate-acceptance"))


def gate_verdict(label, original, candidate_path):
    case = dict(name=os.path.basename(candidate_path), expect="rewritten", images=1)
    try:
        return gate.check_candidate(original, candidate_path, case, SCRATCH,
                                    GATE_EVIDENCE, label)
    except Exception as error:      # a crash is a verdict too, and a different one
        return dict(accepted=None,
                    problems=["CRASH %s: %s" % (type(error).__name__, error)],
                    crash="%s: %s" % (type(error).__name__, error),
                    fitsverify_exit=None, funpack_exit=None)


def header_diff_summary(result):
    return {hdu: len(cards) for hdu, cards in (result.get("header_diff") or {}).items()}


# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("0. Provenance")
print("=" * 78)

head = subprocess.run(["git", "-C", REPO, "rev-parse", SHA], capture_output=True,
                      text=True).stdout.strip()
print("reviewed SHA          :", SHA)
print("git resolves it to    :", head)
print("python                :", platform.python_version(), platform.platform())
print("numpy                 :", np.__version__)
try:
    import astropy
    print("astropy               :", astropy.__version__)
    ASTROPY = astropy.__version__
except Exception as error:                     # the oracle needs it
    print("astropy               : absent (%s)" % error)
    ASTROPY = "absent"
which = subprocess.run(["bash", "-lc", "command -v cargo || true"], capture_output=True,
                       text=True).stdout.strip()
print("cargo                 :", which or "absent")
print("rustc                 :", "absent" if not which else "present")

PROVENANCE = dict(
    reviewed_sha=SHA,
    git_resolves_to=head,
    python=platform.python_version(),
    platform=platform.platform(),
    numpy=np.__version__,
    astropy=ASTROPY,
    rustc="absent: `cargo`/`rustc` not installed; static.rust-lang.org reachable: no",
    blobs={path: blob_sha256(path) for path in (
        ".github/scripts/fits-heasarc.py",
        ".github/scripts/fits-oracle.py",
        "src/formats/fits.rs",
        ".github/workflows/fits-heasarc.yml")},
)

banner = recorder.run("fitsverify-banner", ["fitsverify", "-l",
                                            os.path.join(FIXTURES, "orig_int16.fits")],
                      env=ENV)
funpack_version = recorder.run("funpack-version", ["funpack", "-V"], env=ENV)
fpack_version = recorder.run("fpack-version", ["fpack", "-V"], env=ENV)
imcopy_usage = recorder.run("imcopy-usage", ["imcopy", "-V"], env=ENV)

TOOL_HASHES = {name: sha256(os.path.join(TOOLS, name))
               for name in ("fitsverify", "fpack", "funpack", "imcopy", "libcfitsio.so")}
for name, digest in TOOL_HASHES.items():
    print("%-21s : %s" % (name, digest))

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("0b. The originals, written by libcfitsio through its own API (04-tools)")
print("=" * 78)

BUILD = recorder.run("build-candidate-writer",
                     ["gcc", "-O1", "-Wall", "-Wextra", "-o", "/tmp/fits-review-make-candidates",
                      os.path.join(ROOT, "04-tools", "make_candidates.c"),
                      "-I" + "/tmp/tools/src", "-L" + TOOLS, "-lcfitsio", "-lm"],
                     env=ENV)
if BUILD["exit"] != 0:
    print(BUILD["stderr"])
    raise SystemExit("the fixture writer did not build")

WRITE = recorder.run("write-originals", ["/tmp/fits-review-make-candidates", FIXTURES], env=ENV)
FIXTURE_SIZES = {name: os.path.getsize(os.path.join(FIXTURES, name))
                 for name in sorted(os.listdir(FIXTURES)) if name.endswith(".fits")}
print(json.dumps(FIXTURE_SIZES, indent=2))

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("1. Gate and oracle, imported from the reviewed SHA")
print("=" * 78)


def load(name):
    path = os.path.join(EXTRACT, name)
    spec = importlib.util.spec_from_file_location(name.replace("-", "_").replace(".py", ""), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    print("%-24s %s" % (name, sha256(path)))
    return module


gate = load("fits-heasarc.py")
oracle = load("fits-oracle.py")
GATE_EVIDENCE = gate_evidence()

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("2. Real candidates: fpack and imcopy of the same build")
print("=" * 78)

CANDIDATES = {}


def candidate(label, argv, cwd, target, source_note):
    path = target if os.path.isabs(target) else os.path.join(cwd or ROOT, target)
    # fpack and imcopy both refuse to overwrite; the tools say so and exit
    # non-zero, which would be recorded as their failure rather than ours.
    if os.path.exists(path):
        os.remove(path)
    run = recorder.run(label, argv, cwd=cwd, env=ENV)
    if not os.path.exists(path):
        print("   no file was written:", path)
        return None
    entry = dict(path=path, source=source_note, created_by=run["argv"],
                 size=os.path.getsize(path), sha256=sha256(path))
    CANDIDATES[os.path.basename(path)] = entry
    print("%-36s %6d bytes %s" % (os.path.basename(path), entry["size"], entry["sha256"][:16]))
    return entry


candidate("fpack-int16-GZIP_1",
          ["fpack", "-g", "-q", "0", "-C", "-O",
           os.path.join(DERIVED, "cand_int16.fpack.fits.fz"),
           os.path.join(FIXTURES, "orig_int16.fits")],
          ROOT, os.path.join(DERIVED, "cand_int16.fpack.fits.fz"), "fpack -g -q 0")

candidate("fpack-float32-GZIP_2",
          ["fpack", "-g2", "-q", "0", "-C", "-O",
           os.path.join(DERIVED, "cand_float32.fpack.fits.fz"),
           os.path.join(FIXTURES, "orig_float32.fits")],
          ROOT, os.path.join(DERIVED, "cand_float32.fpack.fits.fz"), "fpack -g2 -q 0")

IMCOPY = [
    ("imcopy-int16-GZIP_1", "orig_int16.fits", "derived/cand_int16.imcopy.fits.fz", "GZIP_1"),
    ("imcopy-float32-GZIP_2", "orig_float32.fits", "derived/cand_float32.imcopy.fits.fz", "GZIP_2"),
    ("imcopy-float32-GZIP_1", "orig_float32.fits", "derived/cand_float32_gzip1.imcopy.fits.fz", "GZIP_1"),
    ("imcopy-float32-nan2", "orig_float32_nan2.fits", "derived/cand_float32_nan2.fits.fz", "GZIP_2"),
    ("imcopy-float32-poszero", "orig_float32_poszero.fits", "derived/cand_float32_poszero.fits.fz", "GZIP_2"),
]
for label, source, target, codec in IMCOPY:
    candidate(label, ["imcopy", source, "%s[compress %s]" % (target, codec)],
              FIXTURES, target, "imcopy '[compress %s]'" % codec)

# Every candidate is decoded by the reference reader and inspected by
# fitsverify: two external witnesses before the gate looks at it.
for name, entry in sorted(CANDIDATES.items()):
    decoded = os.path.join(SCRATCH, "decoded-" + name)
    if os.path.exists(decoded):
        os.remove(decoded)
    entry["funpack"] = recorder.run("funpack-" + name,
                                    ["funpack", "-C", "-O", decoded, entry["path"]], env=ENV)
    entry["decoded"] = decoded if entry["funpack"]["exit"] == 0 else None
    entry["fitsverify"] = recorder.run("fitsverify-" + name,
                                       ["fitsverify", "-l", entry["path"]], env=ENV)
    entry["fitsverify_exit"] = entry["fitsverify"]["exit"]
    entry["funpack_exit"] = entry["funpack"]["exit"]

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("2b. Are the candidates different files?")
print("=" * 78)

IDENTITY = {}
for name, entry in sorted(CANDIDATES.items()):
    raw = open(entry["path"], "rb").read()
    codec_at = raw.find(b"ZCMPTYPE")
    quant_at = raw.find(b"ZQUANTIZ")
    IDENTITY[name] = dict(
        size=entry["size"], sha256=entry["sha256"],
        zcmptype=raw[codec_at:codec_at + 40].decode("ascii", "replace").strip()
        if codec_at >= 0 else "",
        zquantiz=raw[quant_at:quant_at + 60].decode("ascii", "replace").strip()
        if quant_at >= 0 else "")
    print("%-34s %6d %s %s" % (name, entry["size"], entry["sha256"][:16],
                               IDENTITY[name]["zcmptype"][:38]))
GROUPS = {}
for name, row in IDENTITY.items():
    GROUPS.setdefault(row["sha256"], []).append(name)
DUPLICATES = [sorted(names) for names in GROUPS.values() if len(names) > 1]
for group in DUPLICATES:
    print("  identical files (%d names): %s" % (len(group), group))

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("3. Gate acceptance path, real files")
print("=" * 78)

GATE_CASES = [
    ("gate-int16-fpack", "orig_int16.fits", "cand_int16.fpack.fits.fz"),
    ("gate-int16-imcopy", "orig_int16.fits", "cand_int16.imcopy.fits.fz"),
    ("gate-float32-fpack", "orig_float32.fits", "cand_float32.fpack.fits.fz"),
    ("gate-float32-imcopy", "orig_float32.fits", "cand_float32.imcopy.fits.fz"),
    ("gate-float32-gzip1", "orig_float32.fits", "cand_float32_gzip1.imcopy.fits.fz"),
    ("gate-float32-nan-payload", "orig_float32.fits", "cand_float32_nan2.fits.fz"),
    ("gate-float32-negative-zero", "orig_float32.fits", "cand_float32_poszero.fits.fz"),
]

GATE_RESULTS = {}
for label, original_name, candidate_name in GATE_CASES:
    result = gate_verdict(label, os.path.join(FIXTURES, original_name),
                          CANDIDATES[candidate_name]["path"])
    GATE_RESULTS[label] = result
    print("%-32s accepted=%-5s problems=%d" % (label, result["accepted"],
                                               len(result["problems"])))
    for problem in result["problems"][:3]:
        print("      %s" % problem)

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("4. Corruption of every generated card (gate verdict)")
print("=" * 78)


def find_cards(raw):
    """(offset of the BINTABLE header, keyword -> [(card_offset, card_bytes)])."""
    start = raw.find(b"XTENSION= 'BINTABLE'")
    if start < 0:
        raise SystemExit("no BINTABLE in the candidate")
    cards = {}
    offset = start
    while True:
        card = raw[offset:offset + 80]
        keyword = card[:8].decode("ascii", "replace").strip()
        if keyword == "END":
            break
        cards.setdefault(keyword, []).append((offset, card))
        offset += 80
    return start, cards


def mutate(source_path, target_path, keyword, transform):
    raw = bytearray(open(source_path, "rb").read())
    _, cards = find_cards(bytes(raw))
    if keyword not in cards:
        return None
    offset, card = cards[keyword][0]
    new_card = transform(bytearray(card))
    if new_card is None:
        return None
    raw[offset:offset + 80] = new_card
    with open(target_path, "wb") as handle:
        handle.write(raw)
    return dict(keyword=keyword, before=card.decode("ascii", "replace"),
                after=bytes(new_card).decode("ascii", "replace"))


def set_number(text):
    """A number or logical, right-justified in columns 11-30, as FITS writes it."""
    def transform(card):
        new = bytearray(card)
        new[10:30] = b" " * 20
        new[30 - len(text):30] = text.encode()
        return new if bytes(new) != bytes(card) else None
    return transform


def replace_text(old, new):
    def transform(card):
        card = bytearray(card)
        index = bytes(card).find(old.encode())
        if index < 0 or len(old) != len(new):
            return None
        card[index:index + len(old)] = new.encode()
        return card
    return transform


def comment_byte(card):
    new = bytearray(card)
    new[55] = ord("X") if new[55] != ord("X") else ord("Y")
    return new if bytes(new) != bytes(card) else None


BASE = CANDIDATES["cand_int16.fpack.fits.fz"]
ORIGINAL_INT16 = os.path.join(FIXTURES, "orig_int16.fits")
MUTATIONS = [
    ("ZIMAGE", set_number("F")),
    ("ZSIMPLE", set_number("F")),
    ("ZBITPIX", set_number("-64")),
    ("ZNAXIS", set_number("3")),
    ("ZNAXIS1", set_number("63")),
    ("ZNAXIS2", set_number("63")),
    ("ZEXTEND", set_number("F")),
    ("ZBITPIX", comment_byte),
    ("ZBITPIX", replace_text("/ number of bits per data pixel", "/ number of bits per data pixeL")),
    ("ZTILE1", set_number("32")),
    ("ZTILE2", set_number("2")),
    ("ZCMPTYPE", replace_text("GZIP_1", "GZIP_2")),
    ("TTYPE1", replace_text("COMPRESSED_DATA", "COMPRESSED_DATB")),
    ("TFORM1", replace_text("1PB(", "1QB(")),
    ("NAXIS2", set_number("63")),
    ("PCOUNT", set_number("72")),
    ("NAXIS1", set_number("16")),
    ("BITPIX", set_number("16")),
    ("NAXIS", set_number("3")),
    ("GCOUNT", set_number("2")),
    ("TFIELDS", set_number("2")),
    ("XTENSION", replace_text("BINTABLE", "AINTABLE")),
    ("EXTNAME", replace_text("COMPRESSED_IMAGE", "COMPRESSED_IMAGF")),
    ("BUNIT", replace_text("COUNTS", "COUNTZ")),
    ("OBJECT", replace_text("M31", "M32")),
    ("COMMENT", comment_byte),
]

MUTANT_RESULTS = []
for index, (keyword, transform) in enumerate(MUTATIONS):
    target = os.path.join(DERIVED, "mutant-%02d.fits.fz" % index)
    change = mutate(BASE["path"], target, keyword, transform)
    label = "mutant-%02d-%s" % (index, keyword)
    if change is None:
        MUTANT_RESULTS.append(dict(label=label, keyword=keyword, applied=False))
        print("%-34s not applied (card absent or value unchanged)" % label)
        continue
    verify = recorder.run("fitsverify-" + label, ["fitsverify", "-l", target], env=ENV)
    result = gate_verdict(label, ORIGINAL_INT16, target)
    row = dict(label=label, keyword=keyword, applied=True,
               change=[change["before"][:50], change["after"][:50]],
               fitsverify_exit=verify["exit"], accepted=result["accepted"],
               problems=result["problems"][:4],
               header_diff=header_diff_summary(result),
               funpack_exit=result.get("funpack_exit"))
    MUTANT_RESULTS.append(row)
    print("%-34s accepted=%-5s fitsverify=%-3s funpack=%-4s %s"
          % (label, result["accepted"], verify["exit"], result.get("funpack_exit"),
             (result["problems"][:1] or ["--"])[0][:70]))

corrupt_path = os.path.join(DERIVED, "mutant-tile-byte.fits.fz")
detail = gate.corrupt_tile(BASE["path"], corrupt_path)
result = gate_verdict("mutant-tile-byte", ORIGINAL_INT16, corrupt_path)
TILE_MUTANT = dict(detail={k: v for k, v in detail.items() if k != "original"},
                   accepted=result["accepted"], problems=result["problems"][:3],
                   fitsverify_exit=result.get("fitsverify_exit"),
                   funpack_exit=result.get("funpack_exit"))
print("%-34s accepted=%-5s funpack=%-4s %s"
      % ("mutant-tile-byte", result["accepted"], result.get("funpack_exit"),
         (result["problems"][:1] or ["--"])[0][:70]))
print("   gate.corrupt_tile: %s" % TILE_MUTANT["detail"])

_, base_cards = find_cards(open(BASE["path"], "rb").read())
GENERATED = sorted(base_cards)
print("   generated cards (%d): %s" % (len(GENERATED), GENERATED))

ROLES = dict(
    XTENSION="table", BITPIX="table", NAXIS="table", NAXIS1="table", NAXIS2="table",
    PCOUNT="table", GCOUNT="table", TFIELDS="table", TTYPE1="table", TFORM1="table",
    ZIMAGE="convention", ZCMPTYPE="convention", ZTILE1="convention", ZTILE2="convention",
    ZSIMPLE="z-form", ZBITPIX="z-form", ZNAXIS="z-form", ZNAXIS1="z-form",
    ZNAXIS2="z-form", ZEXTEND="z-form", EXTNAME="mapped-or-named",
    BUNIT="copied", OBJECT="copied", COMMENT="copied",
)
CARD_ROLES = {name: ROLES.get(name, "unclassified") for name in GENERATED}

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("5. Content isolation: the gate's own compare_arrays")
print("=" * 78)

CONTENT = {}
before_float = gate.parse(open(os.path.join(FIXTURES, "orig_float32.fits"), "rb").read())[0]
before_int = gate.parse(open(ORIGINAL_INT16, "rb").read())[0]

# The API-written candidates are the bit-exact ones (04-tools proved every
# special comes back unchanged); the fpack/imcopy ones above are not, and are
# used only for the header question.
API = {name: dict(path=os.path.join(FIXTURES, name), source=None)
       for name in ("cand_float32_gzip2.fits", "cand_float32_gzip1.fits",
                    "cand_float32_nan2.fits", "cand_float32_poszero.fits")}
for name in API:
    out = os.path.join(SCRATCH, name.replace(".fits", "") + ".apiunpacked.fits")
    if os.path.exists(out):
        os.remove(out)
    run = recorder.run("funpack-" + name, ["funpack", "-C", "-O", out, API[name]["path"]],
                       env=ENV)
    API[name]["decoded"] = out if run["exit"] == 0 else None

for label, candidate_name, before in (
    ("content-intact", "cand_float32_gzip2.fits", before_float),
    ("content-nan-payload", "cand_float32_nan2.fits", before_float),
    ("content-negative-zero", "cand_float32_poszero.fits", before_float),
    ("content-int16-intact", "cand_int16.fpack.fits.fz", before_int),
):
    if candidate_name in API:
        reconstructed = API[candidate_name]["decoded"]
    else:
        reconstructed = CANDIDATES[candidate_name]["decoded"]
    after = gate.parse(open(reconstructed, "rb").read())[0]
    problems = gate.compare_arrays(before, after)
    CONTENT[label] = problems
    print("%-26s problems=%d %s" % (label, len(problems), problems[:1]))

print()
print("gate.check_candidate on the API-written float candidates:")
print("(one should pass if the codec is all that differs; the header decides)")
GATE_API = {}
for label, name in (("gate-api-float32-gzip2", "cand_float32_gzip2.fits"),
                    ("gate-api-float32-gzip1", "cand_float32_gzip1.fits")):
    result = gate_verdict(label, os.path.join(FIXTURES, "orig_float32.fits"),
                          os.path.join(FIXTURES, name))
    GATE_API[label] = dict(accepted=result["accepted"], problems=result["problems"][:4],
                           header_diff=header_diff_summary(result))
    print("  %-26s accepted=%-5s %s" % (label, result["accepted"],
                                        (result["problems"][:2] or ["--"])))

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("5c. The layout `write_tiled` describes, written a second time")
print("=" * 78)

import synthetic_layout

SYNTHETIC = {}
for label, name, floating in (
    ("synthetic-int16-gzip1", "orig_int16.fits", False),
    ("synthetic-float32-gzip2", "orig_float32.fits", True),
):
    target = os.path.join(DERIVED, label + ".fits.fz")
    synthetic_layout.build(os.path.join(FIXTURES, name), target, floating)
    verify = recorder.run("fitsverify-" + label, ["fitsverify", "-l", target], env=ENV)
    result = gate_verdict("gate-" + label, os.path.join(FIXTURES, name), target)
    SYNTHETIC[label] = dict(path=target, sha256=sha256(target), size=os.path.getsize(target),
                            fitsverify_exit=verify["exit"], accepted=result["accepted"],
                            problems=result["problems"][:4])
    print("%-26s %6d bytes accepted=%-5s fitsverify=%-3s %s"
          % (label, os.path.getsize(target), result["accepted"], verify["exit"],
             (result["problems"][:1] or ["--"])[0][:60]))

print()
print("A card the writer invents and `check_tiled` never compares (ZVAL1):")
zval_target = os.path.join(DERIVED, "synthetic-zval1-float.fits.fz")
zval_change = mutate(SYNTHETIC["synthetic-float32-gzip2"]["path"], zval_target,
                     "ZVAL1", set_number("1"))
if zval_change is None:
    SUPPLEMENTARY = dict(applied=False, reason="ZVAL1 not found in the synthetic file")
    print("  not applied: %s" % SUPPLEMENTARY["reason"])
else:
    zval_verify = recorder.run("fitsverify-supp-zval1", ["fitsverify", "-l", zval_target], env=ENV)
    zval_result = gate_verdict("supp-zval1-float", os.path.join(FIXTURES, "orig_float32.fits"),
                               zval_target)
    SUPPLEMENTARY = dict(applied=True, before=zval_change["before"][:40],
                         after=zval_change["after"][:40],
                         accepted=zval_result["accepted"],
                         problems=zval_result["problems"][:4],
                         fitsverify_exit=zval_verify["exit"],
                         header_diff=header_diff_summary(zval_result))
    print("  ZVAL1 0 -> 1 in a GZIP_2 float candidate")
    print("  gate accepted=%-5s fitsverify=%s %s"
          % (zval_result["accepted"], zval_verify["exit"],
             (zval_result["problems"][:1] or ["--"])[0][:70]))

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("6. Oracle check_rewritten on the same files")
print("=" * 78)

original_float_bytes = open(os.path.join(FIXTURES, "orig_float32.fits"), "rb").read()
raw_float = original_float_bytes[2880:2880 + 64 * 64 * 4]
expected_float = np.frombuffer(raw_float, dtype=">f4").astype(np.float32).reshape(64, 64)

ORACLE_RESULTS = {}
for label, candidate_name in (
    ("oracle-float32-gzip2", "cand_float32_gzip2.fits"),
    ("oracle-float32-gzip1", "cand_float32_gzip1.fits"),
    ("oracle-float32-nan-payload", "cand_float32_nan2.fits"),
    ("oracle-float32-negative-zero", "cand_float32_poszero.fits"),
    ("oracle-synthetic-float32-gzip2", "@synthetic-float32-gzip2"),
):
    case = dict(expected={0: expected_float}, arrays=[(0, 1)], metadata=[],
                tables=[1], verbatim=[])
    if candidate_name.startswith("@"):
        path = SYNTHETIC[candidate_name[1:]]["path"]
    else:
        path = API[candidate_name]["path"]
    problems = oracle.check_rewritten(path, original_float_bytes, case)
    ORACLE_RESULTS[label] = problems
    print("%-32s problems=%d %s" % (label, len(problems), problems[:3]))

print()
print("gate vs oracle on the same file (GZIP_1 float):")
print("  gate   :", [p[:60] for p in GATE_RESULTS["gate-float32-gzip1"]["problems"]][:3])
print("  oracle :", [p[:60] for p in ORACLE_RESULTS["oracle-float32-gzip1"]][:3])

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("7. gate --self-check, as a command line")
print("=" * 78)

SELF_CHECK = recorder.run(
    "gate-self-check",
    [sys.executable, os.path.join(EXTRACT, "fits-heasarc.py"), "--self-check",
     "--work", os.path.join(SCRATCH, "selfcheck-work"),
     "--evidence", os.path.join(SCRATCH, "selfcheck-evidence")],
    env=ENV, timeout=900)

# ---------------------------------------------------------------------------
print()
print("=" * 78)
print("8. Write the record")
print("=" * 78)
payload = dict(
    sha=SHA,
    provenance=PROVENANCE,
    tools=dict(
        fitsverify_banner=(banner["stdout"] + banner["stderr"]).splitlines()[:3],
        funpack_version=funpack_version["stdout"].strip(),
        fpack_version=fpack_version["stdout"].strip(),
        imcopy_usage=[line for line in imcopy_usage["stdout"].splitlines() if line.strip()][:2],
        binaries=TOOL_HASHES,
        cfitsio_commit="113781d8aa442cf8d3c27295d9084674b8b039f2",
        cfitsio_archive_sha256="d93c0de372a264156d2f3e1eab2d4159e132c35c2216f71c0af0009b92a72b5e",
    ),
    fixtures=FIXTURE_SIZES,
    candidates={k: dict(size=v["size"], sha256=v["sha256"], source=v["source"],
                        fitsverify_exit=v.get("fitsverify_exit"),
                        funpack_exit=v.get("funpack_exit"))
                for k, v in CANDIDATES.items()},
    candidate_identity=IDENTITY,
    duplicate_candidates=DUPLICATES,
    gate_results={k: dict(accepted=v["accepted"], problems=v["problems"],
                          fitsverify_exit=v.get("fitsverify_exit"),
                          funpack_exit=v.get("funpack_exit"),
                          header_diff=header_diff_summary(v))
                  for k, v in GATE_RESULTS.items()},
    gate_api_float=GATE_API,
    mutants=MUTANT_RESULTS,
    tile_mutant=TILE_MUTANT,
    generated_cards=GENERATED,
    card_roles=CARD_ROLES,
    content_isolation=CONTENT,
    synthetic_layout={k: {kk: vv for kk, vv in v.items() if kk != "path"}
                      for k, v in SYNTHETIC.items()},
    supplementary_zval1=SUPPLEMENTARY,
    oracle=ORACLE_RESULTS,
    gate_self_check=dict(exit=SELF_CHECK["exit"],
                         tail=SELF_CHECK["stdout"].strip().splitlines()[-3:]),
    runs=[dict(label=e["label"], argv=e["argv"], exit=e["exit"]) for e in recorder.entries],
)
path = os.path.join(EVIDENCE, "baseline.json")
with open(path, "w") as handle:
    json.dump(payload, handle, indent=2)
print("-> %s (%d recorded runs)" % (path, len(recorder.entries)))
