#!/usr/bin/env python3
"""What the two reference writers actually changed in the float candidate.

The gate reports "array bytes differ (16384 -> 16384 bytes, first difference at
0)" for `fpack -g2 -q 0` and at 1 for `imcopy`.  That is a verdict, not a
description.  This script unpacks each candidate with the real `funpack` and
prints every differing pixel as bytes and as a float, so the report can say
what changed instead of where the first difference is.

It also prints the header cards that say whether the file claims to be
lossless, since the convention's §4 note makes the absence of ZSCALE/ZZERO an
indication of lossless compression.
"""
import os
import struct
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIXTURES = os.path.join(ROOT, "01-fixtures")
DERIVED = os.path.join(FIXTURES, "derived")
TOOLS = "/tmp/tools/src/.libs"

os.environ["PATH"] = TOOLS + ":" + os.environ["PATH"]
os.environ["LD_LIBRARY_PATH"] = TOOLS


def array_bytes(path):
    raw = open(path, "rb").read()
    # Every primary image here starts at 0 and holds one 2880-byte header.
    return raw[2880:2880 + 64 * 64 * 4]


def describe(original, candidate, label):
    out = os.path.join("/tmp", "unpacked-%s.fits" % label)
    if os.path.exists(out):
        os.remove(out)
    run = subprocess.run(["funpack", "-C", "-O", out, candidate],
                         capture_output=True, text=True, env=dict(os.environ))
    print("=" * 78)
    print("%s: funpack exit %d" % (label, run.returncode))
    if run.stdout.strip():
        print("  stdout:", run.stdout.strip())
    if run.stderr.strip():
        print("  stderr:", run.stderr.strip())
    if run.returncode != 0:
        return
    before = array_bytes(original)
    after = array_bytes(out)
    diffs = [i for i in range(min(len(before), len(after))) if before[i] != after[i]]
    pixels = sorted({i // 4 for i in diffs})
    print("  differing bytes: %d, in pixels: %s" % (len(diffs), pixels[:20]))
    for pixel in pixels[:12]:
        old = struct.unpack(">f", before[pixel * 4:pixel * 4 + 4])[0]
        new = struct.unpack(">f", after[pixel * 4:pixel * 4 + 4])[0]
        print("    pixel %-3d %s -> %s   %r -> %r"
              % (pixel, before[pixel * 4:pixel * 4 + 4].hex(),
                 after[pixel * 4:pixel * 4 + 4].hex(), old, new))
    raw = open(candidate, "rb").read()
    for keyword in (b"ZCMPTYPE", b"ZQUANTIZ", b"ZSCALE", b"ZZERO", b"ZBLANK"):
        where = raw.find(keyword)
        if where < 0:
            print("  %-8s absent" % keyword.decode())
        else:
            print("  %-8s |%s|" % (keyword.decode(),
                                   raw[where:where + 80].decode("ascii", "replace").rstrip()))


def main():
    original = os.path.join(FIXTURES, "orig_float32.fits")
    for label, candidate in (
        ("fpack-g2-q0", os.path.join(DERIVED, "cand_float32.fpack.fits.fz")),
        ("imcopy-gzip2", os.path.join(DERIVED, "cand_float32.imcopy.fits.fz")),
    ):
        describe(original, candidate, label)
    print()
    print("Both candidates are the reference writer's own output for the same original.")
    print("Neither is a tzim candidate; nothing here is a statement about tzim.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
