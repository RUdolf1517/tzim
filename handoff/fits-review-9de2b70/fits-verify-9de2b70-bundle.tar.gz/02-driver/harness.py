#!/usr/bin/env python3
"""Runs one command and records everything about it.

Every run leaves four files beside the others: the command line as it was
written, stdout, stderr and the exit code, each named `NN-label.*` in the order
the runs happened. Tool output is captured as bytes and decoded with `replace`:
`fitsverify` and `funpack` print raw bytes from corrupted files, and a decode
that raises would lose the run it was recording.
"""
import os
import shlex
import subprocess


class Recorder:
    def __init__(self, root):
        self.root = root
        os.makedirs(root, exist_ok=True)
        self.entries = []
        self._number = 0

    def _write(self, stem, suffix, payload):
        mode = "wb" if isinstance(payload, bytes) else "w"
        with open(os.path.join(self.root, stem + "." + suffix), mode) as handle:
            handle.write(payload)

    def run(self, label, argv, cwd=None, env=None, timeout=900):
        self._number += 1
        stem = "%02d-%s" % (self._number, label)
        line = (("cd %s && " % cwd) if cwd else "") + " ".join(shlex.quote(a) for a in argv)
        try:
            done = subprocess.run(argv, cwd=cwd, env=env, timeout=timeout,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            code, out, err = done.returncode, done.stdout, done.stderr
        except subprocess.TimeoutExpired as expired:
            code = None
            out = expired.stdout or b""
            err = (expired.stderr or b"") + b"\nTIMEOUT after %d seconds\n" % timeout
        self._write(stem, "cmd", line + "\n")
        self._write(stem, "stdout", out)
        self._write(stem, "stderr", err)
        self._write(stem, "exit", "%s\n" % ("TIMEOUT" if code is None else code))
        entry = dict(label=label, argv=[str(a) for a in argv], cwd=cwd,
                     exit=code, stdout=out.decode("utf-8", "replace"),
                     stderr=err.decode("utf-8", "replace"))
        self.entries.append(entry)
        print("%-46s exit=%s" % (label, entry["exit"]))
        return entry
