#!/usr/bin/env python3
"""An independent exact-arithmetic check of the decimal test in `fits.rs`.

`src/formats/fits.rs` at 9de2b70 decides whether `BSCALE` is exactly 1 and
`BZERO` is exactly 0 without converting to `f64`.  There is no Rust toolchain
here, so the Rust function cannot be called.  What can be done is to write the
same algorithm a second time, from the source text, and to compare its answers
with `decimal.Decimal`, which is exact: if the two disagree, one of them is
wrong, and the disagreement is visible.

This is not a run of the reviewed code.  It is a check that the algorithm the
report describes has the property the report claims, and it is labelled as such
in the report.
"""
import decimal
import random
import sys

I64_MAX = 2**63 - 1
I64_MIN = -(2**63)


def sat_add(a, b):
    total = a + b
    return max(min(total, I64_MAX), I64_MIN)


def decimal_parts(text):
    """`decimal_parts` from `fits.rs`, with the same saturation rules."""
    text = text.strip()
    if not text:
        return None
    if text[0] in "+-":
        negative = text[0] == "-"
        text = text[1:]
    else:
        negative = False
    if not text:
        return None
    exponent_at = None
    for index, char in enumerate(text):
        if char in "EeDd":
            exponent_at = index
            break
    if exponent_at is not None:
        exponent = text[exponent_at + 1:]
        if not exponent:
            return None
        if exponent[0] in "+-":
            exponent_negative = exponent[0] == "-"
            digits_text = exponent[1:]
        else:
            exponent_negative = False
            digits_text = exponent
        if not digits_text or not all(c.isdigit() for c in digits_text):
            return None
        magnitude = 0
        for char in digits_text:
            magnitude = sat_add(magnitude * 10, ord(char) - ord("0"))
        if exponent_negative:
            exponent_value = I64_MIN if magnitude > I64_MAX else -magnitude
        else:
            exponent_value = min(magnitude, I64_MAX)
        mantissa = text[:exponent_at]
    else:
        mantissa, exponent_value = text, 0

    digits = []
    fractional = 0
    after_point = False
    for char in mantissa:
        if char == "." and not after_point:
            after_point = True
        elif char.isdigit():
            digits.append(char)
            if after_point:
                fractional += 1
        else:
            return None
    if not digits:
        return None
    return negative, "".join(digits), fractional, exponent_value


def decimal_is_zero(text):
    parts = decimal_parts(text)
    if parts is None:
        return None
    return all(digit == "0" for digit in parts[1])


def decimal_is_one(text):
    parts = decimal_parts(text)
    if parts is None:
        return None
    negative, digits, fractional, exponent = parts
    if negative:
        return False
    first = next((i for i, digit in enumerate(digits) if digit != "0"), None)
    if first is None:
        return False
    if digits[first] != "1" or any(digit != "0" for digit in digits[first + 1:]):
        return False
    trailing = len(digits) - first - 1
    if fractional > I64_MAX or trailing > I64_MAX:
        return None
    scale = sat_add(sat_add(exponent, -fractional), trailing)
    return scale == 0


def exact(text, target):
    try:
        return decimal.Decimal(text.strip().replace("D", "E").replace("d", "e")) == target
    except decimal.InvalidOperation:
        return None


FIXED = [
    # (value, is_one, is_zero) as exact decimals say it
    ("1", True, False),
    ("1.0", True, False),
    ("1.000000000000", True, False),
    ("0.1E+1", True, False),
    (".1E1", True, False),
    ("10D-1", True, False),
    ("+1", True, False),
    ("1E+0", True, False),
    ("1E-0", True, False),
    ("1.0E-0", True, False),
    ("0001.0000", True, False),
    ("1.00000000000000001", False, False),
    ("0.9999999999999999999", False, False),
    ("2", False, False),
    ("10", False, False),
    ("0.1", False, False),
    ("-1", False, False),
    ("1E+1", False, False),
    ("1D+400", False, False),
    ("1D-400", False, False),
    ("-0", False, True),
    ("+0.000", False, True),
    ("0", False, True),
    ("0E+999999999999999999999", False, True),
    ("1E-999999999999999999999", False, False),
    ("1E+999999999999999999999", False, False),
    ("", None, None),
    ("1E", None, None),
    ("1E+", None, None),
    ("1.2.3", None, None),
    ("'1'", None, None),
    ("T", None, None),
]


def main():
    problems = []
    for text, want_one, want_zero in FIXED:
        got_one = decimal_is_one(text)
        got_zero = decimal_is_zero(text)
        if got_one != want_one:
            problems.append("is_one(%r) = %r, exact arithmetic says %r" % (text, got_one, want_one))
        if got_zero != want_zero:
            problems.append("is_zero(%r) = %r, exact arithmetic says %r" % (text, got_zero, want_zero))
        print("  %-30r is_one=%-5s is_zero=%-5s" % (text, got_one, got_zero))

    random.seed(20261026)
    alphabet = "0123456789.eEdD+-  "
    disagree = 0
    over_refusal = 0
    for _ in range(200000):
        length = random.randint(1, 12)
        text = "".join(random.choice(alphabet) for _ in range(length))
        got_one = decimal_is_one(text)
        got_zero = decimal_is_zero(text)
        truth_one = exact(text, decimal.Decimal(1))
        truth_zero = exact(text, decimal.Decimal(0))
        if truth_one is not None and got_one is True and not truth_one:
            disagree += 1
            problems.append("false accept: is_one(%r) = True, value is not 1" % text)
        if truth_zero is not None and got_zero is True and not truth_zero:
            disagree += 1
            problems.append("false accept: is_zero(%r) = True, value is not 0" % text)
        if truth_one and got_one is not True:
            over_refusal += 1
        if truth_zero and got_zero is not True:
            over_refusal += 1
    print()
    print("random strings: 200000; false accepts: %d; refusals of an exact identity: %d"
          % (disagree, over_refusal))
    print("fixed cases: %d" % len(FIXED))
    if problems:
        print("PROBLEMS:")
        for problem in problems[:20]:
            print("  " + problem)
        return 1
    print()
    print("what a conversion through f64 would do to the same two values:")
    for text in ("1.00000000000000001", "1E-400", "1E+100"):
        value = float(text)
        print("  float(%-22r) == 1.0: %-5s  == 0.0: %-5s" % (text, value == 1.0, value == 0.0))
    print("  a BSCALE that rounds to 1.0, and a BZERO that underflows to 0.0, are the two")
    print("  ways an f64 test says 'identity' about a value that is not identity.")
    print("no false accept and no exact identity refused")
    return 0


if __name__ == "__main__":
    sys.exit(main())
