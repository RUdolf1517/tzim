#!/usr/bin/env python3
"""Builds a candidate with the layout `write_tiled` at 9de2b70 produces.

No tzim binary exists here, so the writer cannot be run.  What can be done is to
write the same file a second time, from `write_tiled`'s source text -- the same
card set, in the same order, with the same formatting helpers -- and then the
gate at the reviewed SHA judges that file.

This tests the *layout the code describes*, not the code.  If the gate rejects
it, either the layout was transcribed wrongly here or a candidate tzim writes
would be rejected by tzim's own gate; the diff says which.
"""
import gzip
import struct

from harness import Recorder  # noqa: F401  (imported by the driver's path)

CARD = 80
RECORD = 2880

# `structural()` in src/formats/fits.rs, verbatim.
EXACT = {"SIMPLE", "XTENSION", "BITPIX", "NAXIS", "PCOUNT", "GCOUNT", "EXTEND", "TFIELDS",
         "THEAP", "EXTNAME", "ZIMAGE", "ZSIMPLE", "ZTENSION", "ZBITPIX", "ZNAXIS", "ZPCOUNT",
         "ZGCOUNT", "ZEXTEND", "ZCMPTYPE", "ZNAME1", "ZVAL1"}
PREFIXES = ("NAXIS", "ZNAXIS", "ZTILE", "TTYPE", "TFORM")


def structural(keyword):
    if keyword in EXACT:
        return True
    for prefix in PREFIXES:
        rest = keyword[len(prefix):] if keyword.startswith(prefix) else None
        if rest and rest.isdigit():
            return True
    return False


def assemble(head, comment=""):
    out = bytearray(b" " * CARD)
    used = min(len(head), CARD)
    out[:used] = head[:used].encode()
    if comment:
        start = max(30, used)
        text = (" / " + comment).encode()
        take = min(len(text), CARD - start)
        out[start:start + take] = text[:take]
    return bytes(out)


def numeric_card(keyword, value, comment=""):
    return assemble("%-8s= %20d" % (keyword, value), comment)


def boolean_card(keyword, value, comment=""):
    return assemble("%-8s= %20s" % (keyword, "T" if value else "F"), comment)


def string_card(keyword, value, comment=""):
    return assemble("%-8s= '%s'" % (keyword, value), comment)


def renamed(card, keyword):
    raw = bytearray(card)
    raw[:8] = b" " * 8
    raw[:len(keyword)] = keyword.encode()
    return bytes(raw)


def write_header(out, cards):
    for card in cards:
        out += card
    out += assemble("END")
    pad(out, len(out) - (len(cards) + 1) * CARD)


def pad(out, from_start):
    """`write_header` pads a header with spaces."""
    length = len(out) - from_start
    padded = (length + RECORD - 1) // RECORD * RECORD
    out.extend(b" " * (padded - length))


def pad_data(out, from_start):
    """`pad_to_record` pads data with zeros, which is what FITS fill bytes are."""
    length = len(out) - from_start
    padded = (length + RECORD - 1) // RECORD * RECORD
    out.extend(b"\x00" * (padded - length))


def split_header(raw, start):
    cards = []
    offset = start
    while True:
        card = raw[offset:offset + CARD]
        if card[:8].decode("ascii", "replace").strip() == "END":
            return cards, offset + CARD
        cards.append(card)
        offset += CARD


def shuffle(block, per_sample):
    count = len(block) // per_sample
    out = bytearray(len(block))
    for byte in range(per_sample):
        for sample in range(count):
            out[byte * count + sample] = block[sample * per_sample + byte]
    return bytes(out)


def build(original_path, out_path, floating, gate=None):
    if gate is None:
        import importlib.util
        import os
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        spec = importlib.util.spec_from_file_location(
            "gate", os.path.join(here, "05-extracted-at-sha", "fits-heasarc.py"))
        gate = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(gate)

    raw = open(original_path, "rb").read()
    hdu = gate.parse(raw)[0]
    cards, after_end = split_header(raw, 0)
    fields = {card[:8].decode().strip(): card for card in cards}
    naxis = int(fields["NAXIS"][10:30])
    axes = [int(fields["NAXIS%d" % (i + 1)][10:30]) for i in range(naxis)]
    bitpix = int(fields["BITPIX"][10:30])
    per_sample = abs(bitpix) // 8
    data = hdu.data
    tile_bytes = axes[0] * per_sample
    tiles = 1
    for axis in axes[1:]:
        tiles *= axis
    assert tile_bytes * tiles == len(data), (tile_bytes, tiles, len(data))

    members = []
    for index in range(tiles):
        tile = data[index * tile_bytes:(index + 1) * tile_bytes]
        body = shuffle(tile, per_sample) if floating else tile
        members.append(gzip.compress(body, 9, mtime=0))
    longest = max(len(member) for member in members)
    heap = b"".join(members)

    out = bytearray()
    write_header(out, [
        boolean_card("SIMPLE", True, "conforms to FITS standard"),
        numeric_card("BITPIX", 8, "array data type"),
        numeric_card("NAXIS", 0, "number of array dimensions"),
        boolean_card("EXTEND", True, ""),
    ])

    table = []
    table.append(string_card("XTENSION", "BINTABLE", "binary table extension"))
    table.append(numeric_card("BITPIX", 8, "array data type"))
    table.append(numeric_card("NAXIS", 2, "number of array dimensions"))
    table.append(numeric_card("NAXIS1", 8, "width of table in bytes"))
    table.append(numeric_card("NAXIS2", tiles, "number of rows in table"))
    table.append(numeric_card("PCOUNT", len(heap), "number of group parameters"))
    table.append(numeric_card("GCOUNT", 1, "number of groups"))
    table.append(numeric_card("TFIELDS", 1, "number of fields in each row"))
    table.append(string_card("TTYPE1", "COMPRESSED_DATA", ""))
    table.append(string_card("TFORM1", "1PB(%d)" % longest, ""))
    table.append(boolean_card("ZIMAGE", True, "extension contains compressed image"))
    table.append(renamed(fields["SIMPLE"], "ZSIMPLE"))
    for source, z in (("BITPIX", "ZBITPIX"), ("NAXIS", "ZNAXIS")):
        table.append(renamed(fields[source], z))
    for index in range(len(axes)):
        table.append(renamed(fields["NAXIS%d" % (index + 1)], "ZNAXIS%d" % (index + 1)))
    for source, z in (("PCOUNT", "ZPCOUNT"), ("GCOUNT", "ZGCOUNT"), ("EXTEND", "ZEXTEND")):
        if source in fields:
            table.append(renamed(fields[source], z))
    table.append(numeric_card("ZTILE1", axes[0], "size of tiles to be compressed"))
    for index in range(2, len(axes) + 1):
        table.append(numeric_card("ZTILE%d" % index, 1, "size of tiles to be compressed"))
    table.append(string_card("ZCMPTYPE", "GZIP_2" if floating else "GZIP_1",
                             "compression algorithm"))
    if floating:
        table.append(string_card("ZNAME1", "NOISEBIT", "floating point quantization level"))
        table.append(numeric_card("ZVAL1", 0, "floating point quantization level"))
    if "EXTNAME" in fields:
        table.append(fields["EXTNAME"])
    else:
        table.append(string_card("EXTNAME", "COMPRESSED_IMAGE",
                                 "name of this binary table extension"))
    for card in cards:
        if not structural(card[:8].decode().strip()):
            table.append(card)
    write_header(out, table)

    start = len(out)
    cursor = 0
    for member in members:
        out += struct.pack(">II", len(member), cursor)
        cursor += len(member)
    out += heap
    pad_data(out, start)
    open(out_path, "wb").write(bytes(out))
    return len(out)
